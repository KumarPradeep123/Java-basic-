package arraysinjava;
public class NumberToWords {
    static String thousands(int n)
    {
        if(n<=999)
            return hundreds(n);
     
        int thousandpart=n/1000;
        int hundredpart=n%1000;
        if(n % 1000==0)
       return tens(thousandpart)+ " " + "thousand";
       return tens(thousandpart)+ " " +"thousand"+ " " + hundreds(hundredpart);
        
    }
    
    static String hundreds(int n)
    {
        if(n<=99)
            return tens(n);
            
        int hundredpart=n/100;
            int tenpart=n%100;
        if(n % 100==0)   
            return units(hundredpart)+ " " +"hundred";
        
            return units(hundredpart)+ " " +"hundred"+ " " + tens(tenpart);
        
        
        
    }
    static String tens(int n)
    {
        if(n<=9)
            return units(n);
        if(n % 10==0)
            return getTens(n);
        if(n>=11 && n<=19)
        {
      switch(n)
      {
          case 11:return "Eleven";
          case 12:return "Twelve";
          case 13:return "Thirteen";
          case 14:return "Fourteen";
          case 15:return "Fifteen";
          case 16:return "Sixteen";
          case 17:return "Seventeen";
          case 18:return "Eighteen";
          case 19:return "Nineteen";
    }
        }
        int tenpart=n /10;
        tenpart=tenpart*10;
        int digitpart =n %10;
        return getTens(tenpart) + " " + units(digitpart);
        
 }
   
    static String getTens(int n)
    {
        switch(n)
        {
            case 10:return "Ten";
            case 20:return"Twenty";
            case 30:return "Thirty";
            case 40:return "Forty";
            case 50:return "Fifty";
            case 60:return "Sixty";
            case 70:return "Seventy";
            case 80:return "Eighty";
            case 90:return "Ninety";
                                
        }
        return "Invalid";
        }
   
    static String units(int n)
    {
        switch(n)
        {
            case 0: return "Zero";
            case 1: return "One";
            case 2: return "Two";
            case 3: return "Three";
            case 4: return "Four";
            case 5: return "Five";
            case 6: return "Six";
            case 7: return "Seven";
            case 8: return "Eight";
            case 9: return "Nine";
                                                         
        }
        return "Invalid";
        }
    public static void main(String[] args)
    {
      for(int n=1000;n<=10000;n++)  
            System.out.println(thousands(n) + ",");
    }
    

}

