/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arraysinjava;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class array4 {
    public static void main (String[] args)
    {
        Scanner s=new Scanner (System.in);
       
        int[] a={2,3,4,2,5,2,5,3,5,2,4};
        System.out.println("count the no. of times");
        int n=s.nextInt();
        int count=0;
        for(int i=0; i<=a.length-1; i++)
        {
            if(a[i]==n)
            {
                count++;
            }
            }
            System.out.println("no. of the element-" + count);
            
        }
}

 
    
