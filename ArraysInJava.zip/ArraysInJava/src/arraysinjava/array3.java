/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arraysinjava;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class array3 {
     public static void main(String[] args)
    {
        Scanner s=new Scanner(System.in);
        int[] a={22,3,2,45,2};
        System.out.println("Enter element to search");
        int n=s.nextInt();
        for(int i=a.length-1;i>=0;i--)
        {
            if(a[i]==n)
            {
                
                System.out.println("Found at " + i);
                return;
            }
        }
        System.out.println("Not found");
    }
}
