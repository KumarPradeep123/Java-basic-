/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arraysinjava;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class array5 {
    public static void main (String[] args)
    {
        Scanner s=new Scanner (System.in);
       
        int[] a={2,3,4,2,5,2,5,3,5,2,4,2};
        System.out.println("enter elements to search");
        int x1=s.nextInt();
        int x2=s.nextInt();
        int count=0;
        for(int i=0; i<=a.length-2; i++)
        {
            if((a[i]==x1) && (a[i+1]==x2))
            {
                    System.out.println("yes, it's present " + i);
                return;
            }
        }
            System.out.println("not found"); 

            
        }
    
}
