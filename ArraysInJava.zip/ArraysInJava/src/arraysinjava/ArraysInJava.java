/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arraysinjava;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class ArraysInJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
     int[] a=new int[n];
     for(int i=0;i<=a.length-1;i++)
         a[i]=s.nextInt();
        System.out.println("\n\n");
     for(int i=0;i<=a.length-1;i++)
            System.out.print(a[i] + ",");
        System.out.println();
     
    }
}
