/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class tanseriesforloop {
    public static void main (String[] args)
    {
        Scanner s=new Scanner (System.in);
        int angle=s.nextInt();
        
        double x=(Math.PI*angle)/180.0;
      
        double term1=x, sum1=0;
        double term2=1, sum2=0;
        double sum;
        for (int i=1; i<=10; i++)
        {
            {
            sum1=sum1+term1;
            term1=(-term1*x*x)/(2*i*(2*i+1));
            }
            
            
            
            {
            sum2=sum2+term2;
            term2=(-term2*x*x)/(2*i*(2*i-1));
            }
        }
             System.out.println(sum2);
             
             System.out.println(sum1);
             sum=sum1/sum2;
             System.out.println(sum + " = " + Math.tan(x));
    }
}
