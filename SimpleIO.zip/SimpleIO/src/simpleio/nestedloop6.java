/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

/**
 *
 * @author PRADY
 */
public class nestedloop6 {
    public static void main (String[] args)
    {
        int n=5;
        int p=(n+1)/2;
        for(int i=1; i<=p; i++)
        {
            for(int j=1; j<=p-i; j++)
                System.out.print(" ");
            for(int k=1; k<=2*i-1; k++)
                System.out.print("O");
            System.out.println();
        }
        for(int i=p-1; i>=1; i--)
        {
            for(int j=1; j<=p-i; j++)
                System.out.print(" ");
            for(int k=1; k<=2*i-1; k++)
                System.out.print("O");
            System.out.println();
        }
    }
    
}
