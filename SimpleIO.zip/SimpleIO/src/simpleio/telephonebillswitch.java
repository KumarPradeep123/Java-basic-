/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class telephonebillswitch {
    public static void main (String[] args)
    {
        Scanner s=new Scanner(System.in);
        int nc=s.nextInt();
        double bill;
        switch(nc/100)
        {
            case 0:
                System.out.println(50);
                break;
                
            case 1:
                bill=50+(nc-99)*0.5;
                System.out.println(bill);
                break;
                
            case 2:
                bill=100+(nc-199)*0.75;
                System.out.println(bill);
                break;
                
            default:
                bill=175+(nc-299);
                System.out.println(bill);
        }
       }
      }
    
    

