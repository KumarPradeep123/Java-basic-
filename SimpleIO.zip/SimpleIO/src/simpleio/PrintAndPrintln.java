/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

/**
 *
 * @author PRADY
 */
public class PrintAndPrintln {
    public static void main(String[] args)
    {
        System.out.print("One");
        System.out.println("Two");
        System.out.print("Three");
    }
}
