/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

/**
 *
 * @author PRADY
 */
public class SimpleIO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("This is the 1st line");
        System.out.println("This is the\n\n\n second line");
        System.out.println("This is the 3rd line");
    }
}
