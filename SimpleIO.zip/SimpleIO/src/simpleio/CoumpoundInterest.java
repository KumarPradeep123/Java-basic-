/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class CoumpoundInterest {
    public static void main (String[] args)
    {
        Scanner s=new Scanner(System.in);
        int p=s.nextInt();
        int r=s.nextInt();
        int t=s.nextInt();
        double a=p*(Math.pow(1+(r/100.0),t));
        double ci=a-p;
        double si=p*r*t/100.0;
        System.out.println(ci);
        System.out.println(si);
    }
}
