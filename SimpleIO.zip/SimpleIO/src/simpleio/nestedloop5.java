/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

/**
 *
 * @author PRADY
 */
public class nestedloop5 
{
    public static void main (String[] args)
    {
        int n=3;
        for(int i=n; i>=1; i--)
        {
            for(int j=1; j<=n-i; j++)
               System.out.print(" ");
           for(int k=1; k<=2*i-1; k++)
                System.out.print("Q");
            System.out.println();
                
        }
    }
    
}
