/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class telephonebill {
    public static void main (String[] args)
    {
        Scanner s=new Scanner(System.in);
        int nc=s.nextInt();
        double totalcast;
        if(nc<=99)
        totalcast=50.0;
        else
    if(nc<=199)
        totalcast=50+(nc-99)*0.5;
        else
        if(nc<=299)
        totalcast=100+(nc-199)*0.75;
        else
        totalcast=175+(nc-299);
        System.out.println(totalcast);
    
    
        
        
        
        
    }
}
