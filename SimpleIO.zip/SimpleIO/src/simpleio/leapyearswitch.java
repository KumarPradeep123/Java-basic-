/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class leapyearswitch {
    public static void main (String[] args)
    {
        Scanner s=new Scanner (System.in);
        int n=s.nextInt();
        switch(n%400)
        {
            case 0:
                System.out.println("it is a leap year");
                break;
            default:
                switch(n%4)
                        {
                    case 0:
                        switch(n%100)
                        {
                            case 0:
                        System.out.println("it is not a leap year");
                                break;
                                default:
                                    System.out.println("Leap Year");
                        }
                        break;
                        default:   
                        System.out.println("it is not a leap year");
                        }
        }
                    
                
                
                
    }
    
}

