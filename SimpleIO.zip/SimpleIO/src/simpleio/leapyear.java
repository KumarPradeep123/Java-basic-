/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class leapyear {
    public static void main (String[] args)
    {
        Scanner s=new Scanner(System.in);
        int l=s.nextInt();
        if(l%100==0)
        {
            if(l%400==0)
               System.out.println("it is a leap year");
            else
               System.out.println("it is not a leap year");
        }
        else if( l%4==0)
        System.out.println("it is a leap year");
        else
            System.out.println("it is not a leap year");
    }  
   }
