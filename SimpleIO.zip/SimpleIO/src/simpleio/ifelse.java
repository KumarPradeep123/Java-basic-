/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

/**
 *
 * @author PRADY
 */
public class ifelse {
    public static void main (String[] args)
    {
        if(5+5==10)
            System.out.println("This is pradeep");
        else
            System.out.println("This is kumar");
        
    }
}
