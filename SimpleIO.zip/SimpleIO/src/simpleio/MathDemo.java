/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

/**
 *
 * @author PRADY
 */
public class MathDemo {
    public static void main(String[] args)
    {
        double x=Math.sqrt(3600);
        System.out.println(x);
        System.out.println(Math.sqrt(1000));
        System.out.println(Math.pow(2, 3));
        System.out.println(Math.max(12, 10));
        System.out.println(Math.PI);
        System.out.println(Math.E);
        System.out.println(Math.sin(90));
       
    }
}
