/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

/**
 *
 * @author PRADY
 */
public class si {
    public static void main (String []args)
    {
        int p=2;
        int r=1;
        int t=5;
        double simpleintrest=p*r*t/100.0;
        System.out.println(simpleintrest);
    }
}
