/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class AreaOfTriangle {
    public static void main (String[] args)
    {
      Scanner s=new Scanner(System.in);
      int a=s.nextInt();
      int b=s.nextInt();
      int c=s.nextInt();
      int S=(a+b+c)/2;
      double area=Math.sqrt(S*(S-a)*(S-b)*(S-c));
      System.out.println(area);
      
    }
}
