/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class SwitchDemo {
    public static void main(String[] args)
    {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        switch(n)
        {
            case 1:
                System.out.println("Sun");
                break;
                case 2:
                System.out.println("Mon");
                    break;
                    case 3:
                System.out.println("Tue");
                        break;
                        case 4:
                System.out.println("Wed");
                            break;
                            case 5:
                System.out.println("Thu");
                                break;
                                case 6:
                System.out.println("Fri");
                                    break;
                                    case 7:
                System.out.println("Sat");
                                        break;
                default:
                System.out.println("Invalid");
        }
    }
}
