/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class factorial2 {
    public static void main(String[] args)
    {
        Scanner s=new Scanner (System.in);
        int a=s.nextInt();
        int b=s.nextInt();
        int p=1;
        int sum=0;
        if(a>b)
        {
            int t=a;
            a=b;
            b=t;
        }
        for(int i=1;i<=a-1;i++)
            p=p*i;
            for (int i=a; i<=b; i++)
            {
                p=p*i;
             sum=sum+p;
            }
                System.out.println(sum);
    }
                
                
                     
    
                 
}
