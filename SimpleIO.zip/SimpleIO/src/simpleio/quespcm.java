/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class quespcm {
    public static void main (String[] args)
    {
        Scanner s=new Scanner(System.in);
        int p=s.nextInt();
        int m=s.nextInt();
        int c=s.nextInt();
        double percentage;
        if(p<40 || c<40 || m<40)
        System.out.println("failed");
else
        {
        percentage=(p+m+c)/3.0;
            System.out.println(percentage);
            System.out.println("passed");
           
            
    
    
  
        
    }
        
        
        
    }
    
}
