/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class telephonebillternary {
    public static void main(String[] args)
 {
     Scanner s=new Scanner(System.in);
     int nc=s.nextInt();
     double bill=(nc<=99)?50:(nc<=199)?50+(nc-99)*0.5:(nc<=299)?100+(nc-199)*0.75:175+(nc-299);
             System.out.println(bill);
 }
    
}
