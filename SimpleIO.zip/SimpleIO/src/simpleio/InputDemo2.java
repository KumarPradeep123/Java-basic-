/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class InputDemo2 {
    public static void main (String[] args)
    {
        Scanner s=new Scanner(System.in);
        int sp=s.nextInt();
        int discount=s.nextInt();
        double mp=sp*100.0/(100-discount);
        System.out.println(mp);
        
    }
    
}
