/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class InputDemo {
    public static void main(String[] args)
    {
        Scanner s=new Scanner(System.in);
    int p=s.nextInt();
    int m=s.nextInt();
    int c=s.nextInt();
    int t=p+m+c;
    int percentage=t/3;
        System.out.println(percentage);
    }
}
