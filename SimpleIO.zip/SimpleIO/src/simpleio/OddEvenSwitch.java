/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class OddEvenSwitch {
    public static void main(String[] args)
    {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        switch(n%2)
        {
            case 0:
                System.out.println("Even");
                break;
                default:
                    System.out.println("Odd");
        }
    }
}
