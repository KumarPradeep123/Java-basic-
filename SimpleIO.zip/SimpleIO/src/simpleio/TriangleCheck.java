/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class TriangleCheck {
    public static void main (String[] args)
    {
        Scanner s=new Scanner(System.in);
        int a=s.nextInt();
        int b=s.nextInt();
        int c=s.nextInt();
        if(a+b>=c && b+c>=a && c+a>=b)
        {
            System.out.println("tringl is possible");
          if(a==b && b==c && c==a)
            System.out.println("equiletral tringle");
        else
        if(a!=b && b!=c && c!=a)
            System.out.println("scalene tringle");
        else
            System.out.println("isosceles tringle");   
        }
        else
            System.out.println("tringle is not possible");
}
}
