/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class sinseriesforloop {
    public static void main (String[] args)
    {
        Scanner s=new Scanner (System.in);
        int angle=s.nextInt();
        double x=(Math.PI*angle)/180.0;
      
        double term=x, sum=0;
        for (int i=1; i<=10; i++)
        {
            
            sum=sum+term;
            
            term=(-term*x*x)/(2*i*(2*i+1));
            
            
        }
        System.out.println(sum + " = " + Math.sin(x));
    }
    
}
