/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

/**
 *
 * @author PRADY
 */
public class ifelse2 {
    public static void main (String[] args)
    {
        if(true)
        {
            System.out.println("This is true 1");
            System.out.println("This is true 2");
        }
        else
        {
            System.out.println("This is false 1");
            System.out.println("This is false 2");
            
        }
              
    }
    
}
