/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class Ternary {
 public static void main(String[] args)
 {
     Scanner s=new Scanner(System.in);
     int a=s.nextInt(),b=s.nextInt(),c=s.nextInt();
     int max=(a>=b)?(a>=c)?a:b:(b>=c)?b:c;
     System.out.println(max);
 }
}
