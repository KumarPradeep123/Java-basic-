/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class SimpleIntrest {
    public static void main (String[] args)
    {
        Scanner s=new Scanner(System.in);
        int p=s.nextInt();
        int r=s.nextInt();
        int t=s.nextInt();
        double SI=(p*r*t)/100.0;
        System.out.println(SI);
    }
}
