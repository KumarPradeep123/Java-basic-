/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

/**
 *
 * @author PRADY
 */
public class a {
    public static void main (String[]args)
    {
       int r=10;
       double areaofcircle=3.14*r*r;
        System.out.println(areaofcircle);
    }
}
