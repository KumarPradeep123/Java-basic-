/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

/**
 *
 * @author PRADY
 */
public class forloop5 {
    public static void main (String[] args)
    {
      for (int i=1; i<20; i++)
            System.out.println(i*(i+1));
    }
    
}
