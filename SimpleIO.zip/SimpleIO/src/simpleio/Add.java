/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

/**
 *
 * @author PRADY
 */
public class Add {
    public static void main(String[] args)
    {
        int l=4,b=5;
        int area=l*b;
        System.out.println(area);
        
    }
}
