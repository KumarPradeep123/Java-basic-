/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class tringle {
    public static void main (String[] args)
    {
        Scanner s=new Scanner(System.in);
        int a=s.nextInt();
        int b=s.nextInt();
        int c=s.nextInt();
        if(a+b>=c && b+c>=a && c+a>=b)
            System.out.println("tringl is possible");
        else
            System.out.println("tringle is not possible");
       
            
        
        
    }
    
}
