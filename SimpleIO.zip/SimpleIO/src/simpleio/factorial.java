/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class factorial {
    public static void main (String[] args)
    {
        Scanner s=new Scanner (System.in);
        int n=s.nextInt();
        int t=1;
        int sum=0;
        for (int i=1; i<=n; i++)
        {
            t=t*i;
        sum=sum+t;
        }
        System.out.println(sum);
        
    }
}
