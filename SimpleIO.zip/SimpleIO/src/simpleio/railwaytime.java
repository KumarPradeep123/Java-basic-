/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class railwaytime {
    public static void main (String[] args)
    {
        Scanner s=new Scanner(System.in);
        int t=s.nextInt();
        int p=s.nextInt();
        
    }
}
