/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class Ternary2 {
    public static void main(String[] args)
 {
     Scanner s=new Scanner(System.in);
     int ap=s.nextInt(),am=s.nextInt(),ac=s.nextInt();
     int bp=s.nextInt(),bm=s.nextInt(),bc=s.nextInt();
     int cp=s.nextInt(),cm=s.nextInt(),cc=s.nextInt();
     double ta=(ap+am+ac)/3.0;
     System.out.println(ta);
     double tb=(bp+bm+bc)/3.0;
     System.out.println(tb);
     double tc=(cp+cm+cc)/3.0;
     System.out.println(tc);
     double max=(ta>=tb)?(ta>=tc)?ta:tc:(tb>=tc)?tb:tc;
     double firstdivision=max;
     System.out.println(firstdivision);
     
 }
}
