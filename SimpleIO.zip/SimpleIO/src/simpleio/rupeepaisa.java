/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class rupeepaisa {
    public static void main (String[] args)
    {
        Scanner s=new Scanner (System.in);
        int r=s.nextInt();
        int p=s.nextInt();
        int totalpaise=100*r + p;
        r=totalpaise/100;
        p=totalpaise%100;
        System.out.println(r);
        System.out.println(p);
          
    }
}
