/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class q {
    public static void main(String[] args)
    {
    Scanner s=new Scanner(System.in);
    int p=s.nextInt();
    int m=s.nextInt();
    int c=s.nextInt();
    int totalsum=p+m+c;
    double percentage=totalsum/3.0;
    System.out.println(percentage);
  
}
}