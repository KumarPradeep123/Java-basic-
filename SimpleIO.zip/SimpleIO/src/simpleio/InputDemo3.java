/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class InputDemo3 {
    public static void main (String[] args)
    {
            Scanner s=new Scanner(System.in);
    int area=s.nextInt();
    double radious=Math.sqrt(area/Math.PI);
        System.out.println(radious);
    }
            
}
