/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleio;

/**
 *
 * @author PRADY
 */
public class forloop2 {
    public static void main (String[] args)
    {
      for (int i=1; i<=10; i++)
            System.out.println(2*i);
    }
}
