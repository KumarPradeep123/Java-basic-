import java.util.Scanner;
public class Rectangle implements figure{
private int l,b;
    public Rectangle(int pa,int br)
    {
        l=pa;
        b=br;
    }
    @Override
    public double area() {
        return l*b;
    }

    @Override
    public double perimeter() {
        return 2*(l+b);
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.print("Enter Length : ");
        int length=s.nextInt();
        System.out.print("Enter Breadth : ");
        int breadth=s.nextInt();
        Rectangle r=new Rectangle(length,breadth);
        System.out.println("Area : "+r.area());
        System.out.println("Perimeter : "+r.perimeter());
    }
}
