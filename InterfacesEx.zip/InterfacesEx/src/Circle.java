import java.util.Scanner;
public class Circle implements figure{
private int radius;
public Circle(int r)
{
    radius=r;
}
    @Override
    public double area() {
        return Math.PI*radius*radius;
    }

    @Override
    public double perimeter() {
        return 2*(Math.PI*radius);
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.println("Enter Radius : ");
        int x=s.nextInt();
        Circle c=new Circle(x);
        System.out.println("Area : "+c.area());
        System.out.println("Perimeter : "+c.perimeter());
    }
}
