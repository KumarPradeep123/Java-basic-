public class interFaceEx implements I1{
        
    @Override
    public void f1() {
        System.out.println("f1 in I1");
    }

    @Override
    public int f2(int n) {
        System.out.println("f2 in I1");
        return n;
    }
    public static void main(String[] args) {
   interFaceEx i=new interFaceEx();
   i.f1();
   i.f2(10);
    }
}
