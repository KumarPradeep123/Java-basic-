package P2;

import java.util.Scanner;

public class Triangle {

    int s1, s2, s3;

    public Triangle(int s1, int s2, int s3) {
        this.s1 = s1;
        this.s2 = s2;
        this.s3 = s3;
    }

    public TriangleType getType() {
        int temp;
        if (s2 > s1) {
            temp = s1;
            s1 = s2;
            s2 = temp;
        }

        if (s3 > s1) {
            temp = s1;
            s1 = s3;
            s3 = temp;
        }

        if ((s2 + s3) < s1) {
            return TriangleType.No;
        } else {
            if (s1 == s2 && s2 == s3) {
                return TriangleType.Equilateral;
            } else if (s1 == s2 || s2 == s3 || s1 == s3) {
                return TriangleType.Isoceles;
            } else {
                return TriangleType.Scalane;
            }
        }
    }

    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.print("Enter Side 1 : ");
        int a=s.nextInt();
        System.out.print("Enter Side 2 : ");
        int b=s.nextInt();
        System.out.print("Enter Side 3 : ");
        int c=s.nextInt();
        Triangle t=new Triangle(a,b,c);
        System.out.println(t.getType()+" Triangle");
    }
}
