package P2;
public enum TriangleType {
    No,Isoceles,Equilateral,Scalane;
}
