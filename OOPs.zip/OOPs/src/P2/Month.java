package P2;
public enum Month {
    January,February,Mar,April,May,June,July,August,September,October,Nov,December;
}
