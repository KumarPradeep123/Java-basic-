package oops;
import java.util.Scanner;
public class triangle {
    int a,b,c;
    public triangle()
    {
        Scanner s=new Scanner(System.in);
        System.out.print("Input Side 1 : ");
        a=s.nextInt();
        System.out.print("Input Side 2 : ");
        b=s.nextInt();
        System.out.print("Input Side 3 : ");
        c=s.nextInt();
    }
    public void CheckTriangle()
    {
        int temp;
        if(b>a)
        {
            temp=a;
            a=b;
            b=temp;
        }
      
            if(c>a)
            {
                temp=a;
                a=c;
                c=temp;
            }
        
        if ((b+c)<a)
        {
            System.out.println("Sorry ! Triangle is not possible.");
        }
        else
        {
            temp=0;
            if(a==b)
                temp++;
            if(b==c)
                temp++;
            if(c==a)
                temp++;
            switch (temp) {
                case 1:
                    System.out.print("Triangle is Isoceles ");
                    break;
                case 3:
                    System.out.print("Triangle is Equilateral ");
                    break;
                case 0:
                    System.out.print("Triangle is Scalen ");
                    break;
                default:
                    break;
            }
                    if((a*a)==((b*b)+(c*c)))
                        System.out.println("and right angled triangle.");
                    else
                        System.out.println("but not a right angeled triangle.");
        }
    }
    public static void main(String[] args) {
        triangle t=new triangle();
        System.out.println(t);
        t.CheckTriangle();
    }

    @Override
    public String toString() {
        return "\nSide 1 = " + a + "\nSide 2 = " + b + "\nSide 3 = " + c;
    }
}
