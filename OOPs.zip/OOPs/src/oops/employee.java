package oops;
import java.util.Scanner;
public class employee extends Person{
    int salary;
    String post;
    public employee()
    {
        super();
        Scanner s=new Scanner(System.in);
        System.out.print("Enter Post : ");
        post=s.nextLine();
        System.out.print("Enter Salary : ");
        salary=s.nextInt();
        System.out.print("\nEmployee details : \n"+super.toString());
    }
    public employee(String fn,String ln,Address a,String s, int p)
    {
        fname=fn;
        lname=ln;
        address=a;
        post=s;
        salary=p;
    }
    public static void main(String[] args) {
        employee e=new employee();
        System.out.print(e);
    }

    @Override
    public String toString() {
        return "\n\tSalary = " + salary + "\n\tPost = " + post;
    }
}