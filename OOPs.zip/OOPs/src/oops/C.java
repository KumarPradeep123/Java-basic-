package oops;
public class C extends B {
    
}
