package oops;
import java.util.Scanner;
class BankAccount {

 private static int account, balance;
 private Person cust_name;

    public BankAccount(int a, int b, Person cname) {
        account = a;
        balance = b;
        cust_name = cname;
    }

    public BankAccount() {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter Customer Details => ");
        cust_name = new Person();
        System.out.print("Enter Account number : ");
        account = s.nextInt();
        System.out.print("Enter Balance : ");
        int x = s.nextInt();
        if(x<=0)
            System.out.println("Sorry entered amount is invalid !!!!");
        else
            balance=x;
        
    }

    public void deposit() {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter amount to be deposited : ");
        int amt = s.nextInt();
        if (amt <= 0) {
            System.out.println("Sorry not valid amount !!!!!");
        } else {
            balance = balance + amt;
            System.out.println("\n! ! ! !  SUCCESS  ! ! ! !");
        }
    }

    public void withdraw() {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter amount to be withdrawn : ");
        int amt = s.nextInt();
        if (amt <= 0||amt>balance) {
            System.out.println("Sorry not valid amount !!!!!");
        } else {
            balance = balance - amt;
            System.out.println("\n! ! ! !  SUCCESS  ! ! ! !");
        }
    }
    
    @Override
    public String toString() {
        return "\n\nCustomer Details : " + cust_name + "\nAccount Number : " + account + "\nOpening Balance : " + balance + "\n\n";
    }

    public static void main(String[] args) {
        BankAccount b1 = new BankAccount();
        System.out.println(b1);
        outer :for(;;)
        {
        System.out.println("\t1.Deposit\n\t2.Withdraw\n\t3.Exit");
        Scanner s = new Scanner(System.in);
        int choice=s.nextInt();
        switch (choice) {
            case 1:
                b1.deposit();
                break;
            case 2:
                b1.withdraw();
                break;
            case 3:
                System.out.println("\nAccount Number : " + account + "\nClosing Balance : " + balance + "\n\n");
                break outer;
            default:
                System.out.println("Wrong choice !!!!");
                break;
        }
        System.out.println("\nAccount Number : " + account + "\nUpdated Balance : " + balance + "\n\n");
        }
    }
}

