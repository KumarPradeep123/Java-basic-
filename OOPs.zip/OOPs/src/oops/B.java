package oops;
public class B extends A
{
    public B()
    {
        super (10);
        System.out.println("0 Parameter in B");
    }
    public B(int x)
    {
        System.out.println("One parameter constructor in A.");
    }
    {
        System.out.println("Object block of B");
    }
}
