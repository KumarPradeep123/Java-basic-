package oops;
import java.util.Scanner;
public class Game_Series {

    public static void main(String[] args) {
        int p1_Wins = 0, p2_Wins = 0;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter First Player Name : ");
        String p1 = s.nextLine();
        System.out.print("Enter Second Player Name : ");
        String p2 = s.nextLine();
        Tic_Tac_Toe game = new Tic_Tac_Toe(p1, p2);
        System.out.println("Enter number of matches in a series : ");
        int series = s.nextInt();
        int x = 1;
        for (int i = 1; i <= series; i++) {
            System.out.println("Match "+i+"\n\tScore of "+p1+" = "+p1_Wins+"\n\tScore of "+p2+" = "+p2_Wins);
            
            for (int a=0;a<3;a++)   //reset board
            {
                for (int b=0;b<3;b++)
                    game.board[a][b]=0;
            }
            int result=game.play();
            if(result==1)
            {
                p1_Wins++;
                System.out.println(p1+" Wins this Match ");
            }
            if(result==2)
            {
                p2_Wins++;
                System.out.println(p2+" Wins this Match ");
            }
            if (p1_Wins >= ((series / 2) + 1)) {
                System.out.println(p1 + " Wins the Series !!!!!");
                break;
            }
            if (p2_Wins >= ((series / 2) + 1)) {
                System.out.println(p2 + " Wins the Series !!!!!");
                break;
            }
            game.current_player_change();
        }
        if (p1_Wins > p2_Wins) {
            System.out.println(p1 + " Wins the Series !!!!!");
        }
        if (p1_Wins < p2_Wins) {
            System.out.println(p2 + " Wins the Series !!!!!");
        }
        if (p1_Wins == p2_Wins) {
            System.out.println("Game Draw !!!!!! ");
        }
    }
}