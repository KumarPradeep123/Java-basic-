package oops;
import java.util.Scanner;
public class Address {
    String street,locality,city,state;
    public Address()
    {
        Scanner s=new Scanner(System.in);
        System.out.print("\tEnter Street name : ");
        street=s.nextLine();
        System.out.print("\tEnter Locality : ");
        locality=s.nextLine();
        System.out.print("\tEnter City : ");
        city=s.nextLine();
        System.out.print("\tEnter State Name : ");
        state=s.nextLine();
    }

    @Override
    public String toString() {
        return "\n\tStreet : " + street + "\n\tLocality : " + locality + "\n\tCity : " + city + "\n\tState : " + state;
    }
}
