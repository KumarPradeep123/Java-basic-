package oops;
public class Rect
	{
		int l,b;
		public Rect(int l,int b)
		{
			this.l=l;
			this.b=b;
		}
		public Rect(int sx)
		{
			this(sx,sx);
		}
		public Rect()
		{
			this(0);
		}
		public String toString()
		{
			return "L = "+l+", B = "+b;
		}
		public void disp()
		{
			System.out.println(this);
		}
		public static void main(String[]args)
		{
			Rect p1=new Rect(10);
			System.out.println(p1);
                        p1.disp();
		}
	}