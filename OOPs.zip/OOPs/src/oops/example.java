package oops;
public class example {
    public int instance_Var;
    public static int static_Var;
    public void print()
    {
        System.out.println("Instance Variable = "+instance_Var);
        System.out.println("Static Variable = "+static_Var);
    }
    public static void main(String[] args) {
        example e1=new example();
        example e2=new example();
        example.static_Var=15;
        e1.instance_Var=10;
        e2.instance_Var=15;
        e1.print();
        e2.print();
    }
}
