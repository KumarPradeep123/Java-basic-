package oops;
import java.util.Scanner;
public class Bill {
    Person customer;
    Product p1,p2;
    public Bill()
    {
        Scanner s=new Scanner (System.in);
        System.out.println("Enter Customer Details : ");
        customer=new Person();
        System.out.println("Enter Product details : ");
        p1=new Product();
        p2=new Product();
    }
    public void total()
    {
        System.out.println("\tTotal : "+ p1.cost() + p2.cost());
    }
    public static void main(String[] args) {
        Bill b=new Bill();
        System.out.println(b);
        b.total();
    }

    @Override
    public String toString() {
        return "\n\nCustomer Details : " + customer + "\nProduct Details : " + p1 +"\n"+  p2 ;
    }
}
