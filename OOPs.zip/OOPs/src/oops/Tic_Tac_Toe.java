package oops;

import java.util.Scanner;

public class Tic_Tac_Toe {

    int[][] board = new int[3][3];
    int currentX, currentY, current_player = 1, blocked_Lines = 0;
    String player1, player2, currentPlayerName;

    public Tic_Tac_Toe(String s1, String s2) {
        player1 = s1;
        player2 = s2;
    }

    public void print_Board() {
        System.out.println();
        System.out.println(" _ _ _ ");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print("|");
                switch (board[i][j]) {
                    case 1:
                        System.out.print("X");
                        break;
                    case 2:
                        System.out.print("O");
                        break;
                    default:
                        System.out.print("_");
                        break;
                }
            }
            System.out.print("|");
            System.out.println();
        }
    }

    public void read_Move() {
        Scanner s = new Scanner(System.in);
        while (true) {
            if (current_player == 1) {
                currentPlayerName = player1;
            } else if (current_player == 2) {
                currentPlayerName = player2;
            }
            System.out.println(currentPlayerName + " enter the X and Y position of your move");
            currentX = s.nextInt();
            currentY = s.nextInt();
            if ((currentX > 2 && currentX < 0) || (currentY > 2 && currentY < 0)) {
                System.out.print("Out of Range !!!!!");
            } else if ((board[currentX][currentY] == 1) || (board[currentX][currentY] == 1)) {
                System.out.println("Invalid move !!!!!");
            } else {
                if (current_player == 1) {
                    board[currentX][currentY] = 1;
                } else {
                    board[currentX][currentY] = 2;
                }
                break;
            }
        }
    }

    public void current_player_change() {
        current_player = 3 - current_player;
        if (current_player == 1) {
            currentPlayerName = player1;
        } else if (current_player == 2) {
            currentPlayerName = player2;
        }
    }

    public int game_state() {
        int p1 = 0, p2 = 0;
        for (int i = 0; i < 3; i++) {//column 1
            if (board[i][0] == 1) {
                p1++;
            }
            if (board[i][0] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 2) {
            blocked_Lines++;
        }
        p1 = 0;
        p2 = 0;
        for (int i = 0; i < 3; i++) {//column 2
            if (board[i][1] == 1) {
                p1++;
            }
            if (board[i][1] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 2) {
            blocked_Lines++;
        }
        p1 = 0;
        p2 = 0;
        for (int i = 0; i < 3; i++) {//column 3
            if (board[i][2] == 1) {
                p1++;
            }
            if (board[i][2] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 2) {
            blocked_Lines++;
        }
        p1 = 0;
        p2 = 0;
        for (int i = 0; i < 3; i++) {//row 1
            if (board[0][i] == 1) {
                p1++;
            }
            if (board[0][i] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 2) {
            blocked_Lines++;
        }
        p1 = 0;
        p2 = 0;
        for (int i = 0; i < 3; i++) {//row 2
            if (board[1][i] == 1) {
                p1++;
            }
            if (board[1][i] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 2) {
            blocked_Lines++;
        }
        p1 = 0;
        p2 = 0;
        for (int i = 0; i < 3; i++) {//row 3
            if (board[2][i] == 1) {
                p1++;
            }
            if (board[2][i] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 2) {
            blocked_Lines++;
        }
        p1 = 0;
        p2 = 0;
        for (int i = 0; i < 3; i++) {//diagonal 1
            if (board[i][i] == 1) {
                p1++;
            }
            if (board[i][i] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 2) {
            blocked_Lines++;
        }
        p1 = 0;
        p2 = 0;
        for (int i = 0; i < 3; i++) {//diagonal 2
            if (board[i][2 - i] == 1) {
                p1++;
            }
            if (board[i][2 - i] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        } else if (p2 == 3) {
            return 2;
        } else if (p1 > 0 && p2 > 2) {
            blocked_Lines++;
        }
        if (blocked_Lines == 7) {
            return 3;
        } else {
            return 0;
        }
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter first Player name : ");
        String first_player = s.nextLine();
        System.out.print("Enter second Player name : ");
        String second_player = s.nextLine();
        Tic_Tac_Toe t = new Tic_Tac_Toe(first_player, second_player);
        if (t.play() == 1) {
            System.out.println(t.player1 + " Wins ");
            return;
        }
        if (t.play() == 2) {
            System.out.println(t.player2 + " Wins ");
            return;
        }
        if (t.play() == 3) {
            System.out.println(" Game is Blocked !!!!!!!");
        }
    }

    public int play() {
        print_Board();
        while (true) {
            read_Move();
            print_Board();
            switch (game_state()) {
                case 1:
                    return 1;
                case 2:
                    return 2;
                case 3:
                    return 3;
                default:
                    break;
            }
            current_player_change();
        }
    }
}
