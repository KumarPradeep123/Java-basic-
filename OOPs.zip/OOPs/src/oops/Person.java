package oops;
import java.util.Scanner;
class Person {
    String fname,lname;
    Address address;
    public Person(String fn,String ln,Address add)
    {
        fname=fn;
        lname=ln;
        address=add;
    }
    public Person()
    {
        Scanner s=new Scanner(System.in);
        System.out.print("\tEnter First Name : ");
        fname=s.nextLine();
        System.out.print("\tEnter Second Name : ");
        lname=s.nextLine();
        System.out.println("Enter Address Details : ");
        address=new Address();
    }
    /*public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter First Name : ");
        String fnm=s.nextLine();
        System.out.println("Enter Last Name : ");
        String lnm=s.nextLine();
        System.out.println("Enter Address : ");
        String ad=s.nextLine();
        XPerson p1=new XPerson(fnm,lnm,ad);
        System.out.println(p1);
    }*/
    @Override
    public String toString() {
        return "\n\tFirst Name = " + fname + "\n\tLast name = " + lname + "\nAddress Details : " + address;
    }
}
