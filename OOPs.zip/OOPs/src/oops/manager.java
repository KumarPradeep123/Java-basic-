package oops;
import java.util.Scanner;
public class manager extends employee{
    String dept;
    employee sec;
    public manager()
    {
        super();
        Scanner s=new Scanner(System.in);
        System.out.print("\nEnter Department : ");
        dept=s.nextLine();
        System.out.print("Enter Secratary Details : \n");
        sec=new employee();
        System.out.println("Manager Details : \n"+super.toString());
    }
    public static void main(String[] args) {
        manager m=new manager();
        System.out.print(m);
    }

    @Override
    public String toString() {
        return "\n\tDepartment = " + dept + "\n\tSecratory = " + sec+"\n";
    }
}
