package oops;
public class A {
    public A(int x)
    {
        System.out.println("One parameter constructor in A.");
    }
    public A()
    {
        System.out.println("Zero parameter constructor in A.");
    }
    {
        System.out.println("Object Block in A");
    }
}
