package oops;
import java.util.Scanner;
public class Rectangle {
    int s1, s2;
    public Rectangle(int a,int b) {
        s1=a;
        s2=b;
    }
    public int area(){
        return s1*s2;
    }
    public int perimeter(){
        return 2*(s1+s2);
    }
    public double diagonal(){
        return Math.sqrt((double)(s1*s1)+(double)(s2*s2));
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the sides ");
        int x=s.nextInt();
        int y=s.nextInt();
        
        Rectangle r=new Rectangle(x,y);     //Object of Reactangle calss
        
        System.out.print("Area = "+r.area());
        System.out.print("\nPerimeter = "+r.perimeter());
        System.out.print("\nDiagonal = "+r.diagonal());
    }
}
