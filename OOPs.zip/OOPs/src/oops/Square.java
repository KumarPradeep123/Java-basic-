package oops;
import java.util.Scanner;
public class Square extends Rectangle{
    
    public Square(int s)
    {
        super(s,s);
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter side of square : ");
        int x=s.nextInt();
        Square sq1=new Square(x);
        System.out.println("Area of square : "+sq1.area());
        System.out.println("Perimeter of square : "+sq1.perimeter());
        System.out.println("Diagonal length of square : "+sq1.diagonal());
    }
}
