package oops;
import java.util.Scanner;
public class Product {
 private String item;
 private int quantity;
  private double price;
    public Product()
    {
        Scanner s=new Scanner(System.in);
        System.out.print("\tEnter Product name : ");
        item=s.nextLine();
        System.out.print("\tEnter Product price : ");
        price=s.nextDouble();
        System.out.print("\tEnter quantity of product : ");
        quantity=s.nextInt();
        System.out.print("\n");
    }
public double cost()
{
    return price * quantity;
}
    @Override
    public String toString() {
        return "\n\tItem name\tQuantity\tPrice\n\t" + item+"\t\t"+quantity+"\t\t"+price+"\n";
    }
}
