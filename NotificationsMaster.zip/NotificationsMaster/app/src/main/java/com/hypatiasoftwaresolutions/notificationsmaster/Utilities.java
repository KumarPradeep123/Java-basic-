package com.hypatiasoftwaresolutions.notificationsmaster;

import android.app.NotificationManager;
import android.content.Context;
import android.media.RingtoneManager;
import android.support.v4.app.NotificationCompat;
import android.widget.Button;
import android.widget.RemoteViews;

/**
 * Created by Admin on 5/16/2016.
 */
public class Utilities {


        public static void SendNotification(String message,Context context)
        {
            NotificationManager notificationManager=(NotificationManager)context.getSystemService(context.NOTIFICATION_SERVICE);
            int notifyId=1;
            NotificationCompat.Builder nBuilder=new NotificationCompat.Builder(context);
            nBuilder.setContentTitle("Receive Notification");
            nBuilder.setSmallIcon(R.drawable.notify);
            nBuilder.setContentText(message);
            RemoteViews rv = new RemoteViews(context.getPackageName(),R.layout.notificationxml);
            nBuilder.setContent(rv);
            rv.setOnClickPendingIntent();
            notificationManager.notify(notifyId, nBuilder.build());
        }
    }

