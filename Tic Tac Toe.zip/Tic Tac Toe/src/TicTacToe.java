
import java.util.Scanner;

public class TicTacToe {

    int[][] board = new int[3][3];
    String p1, p2;
    int currentx, currenty, current_playerno;
    String currentplayername;

    public TicTacToe() {
        current_playerno = 1;
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the first player name=");
        p1 = s.nextLine();
        System.out.println("Enter the Second  player name=");
        p2 = s.nextLine();
    }

    public void play() {
        print_board();
        while (true) {
            if(current_playerno==1)
                read_move();
            if(current_playerno==2)
                computerGamePlay();
            print_board();
            int status = gameState();
            if (status == 1) {
                System.out.println(p1 + " wins");
                return;
            }
            if (status == 2) {
                System.out.println(p2 + " wins");
                return;
            }
            if (status == 3) {
                System.out.println("Game draw/blocked");
                return;
            }
            nextPlayer();
        }
    }

    public void nextPlayer() {
        current_playerno = 3 - current_playerno;
        if (current_playerno == 1) {
            currentplayername = p1;
        } else {
            currentplayername = p2;
        }
    }

    public void print_board() {

        for (int i = 0; i <= board.length - 1; i++) {
            for (int j = 0; j <= board.length - 1; j++) {
                if (board[i][j] == 0) {
                    System.out.print("_\t");
                } else if (board[i][j] == 1) {
                    System.out.print("X\t");
                } else if (board[i][j] == 2) {
                    System.out.print("O\t");
                }
            }
            System.out.println();
        }

    }

    public void read_move() {
        Scanner s = new Scanner(System.in);
        while (true) {
            System.out.println("Enter the x and y position " + currentplayername);
            currenty = s.nextInt();
            currentx = s.nextInt();
            if (currentx < 0 || currentx > 2 || currenty > 2 || currenty < 0) {
                System.out.println("Sorry!! out of Range please enter the  right position");
                continue;
            }
            if (board[currenty][currentx] != 0) {
                System.out.println("Sorry!! already occupied. Try again");
                continue;
            }

            board[currenty][currentx] = current_playerno;
            break;
        }
    }

    public int gameState() {
        //0 for continue
        // 1 for p1 wins
        //2 for p2 wins
        //3 for blocked
        int blockedlines=0, p1, p2;
        //**********************************Top Line*************************************************
        p1 = p2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[0][i] == 1) {
                p1++;
            }
            if (board[0][i] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 0) {
            blockedlines++;
        }
        //*********************************Second line**************************************************
        p1 = p2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[1][i] == 1) {
                p1++;
            }
            if (board[1][i] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 0) {
            blockedlines++;
        }

        //**********************************third line*************************************************
        p1 = p2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[2][i] == 1) {
                p1++;
            }
            if (board[2][i] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 0) {
            blockedlines++;
        }
        //*************************************first column**********************************************************
        p1 = p2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[i][0] == 1) {
                p1++;
            }
            if (board[i][0] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 0) {
            blockedlines++;
        }
        //**************************************Second column*********************************************************************
        p1 = p2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[i][1] == 1) {
                p1++;
            }
            if (board[i][1] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 0) {
            blockedlines++;
        }
        //**************************************Third column**********************************************************************************
        p1 = p2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[i][2] == 1) {
                p1++;
            }
            if (board[i][2] == 2) {
                p2++;
            }
        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 0) {
            blockedlines++;
        }

        //**************************************left to right diagonal*******************************************************
        p1 = p2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[i][i] == 1) {
                p1++;
            }
            if (board[i][i] == 2) {
                p2++;
            }

        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 0) {
            blockedlines++;
        }

        //***************************************Right to left diagonal****************************************************************************
        p1 = p2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[i][2 - i] == 1) {
                p1++;
            }
            if (board[i][2 - i] == 2) {
                p2++;
            }

        }
        if (p1 == 3) {
            return 1;
        }
        if (p2 == 3) {
            return 2;
        }
        if (p1 > 0 && p2 > 0) {
            blockedlines++;
        }
        //*******************************************************************************************************************
        if (blockedlines == 8) {
            return 3;
        }
        return 0;

    }

    public void computerGamePlay() {
        //0 for continue
        // 1 for p1 wins
        //2 for p2 wins
        //3 for blocked
        System.out.println(currentplayername+"'s turn");
        int pl1, pl2;
        //**********************************Top Line*************************************************
        pl1 = pl2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[0][i] == 1) {
                pl1++;
            }
            if (board[0][i] == 2) {
                pl2++;
            }
        }
        
        
        //Computer plays
        
        if(pl1==0&&pl2==2)
        {
            for(int i=0;i<3;i++)
            {
                if(board[0][i]==0)
                {
                    board[0][i]=2;
                    System.out.println("0 "+i);
                    return;
                }
            }
        }
        //computer blocks opponents winning
        if(pl1==2&&pl2==0)
        {
            for(int i=0;i<3;i++)
            {
                if(board[0][i]==0)
                {
                    board[0][i]=2;
                    System.out.println("0 "+i);
                    return;
                }
            }
        }
        //*********************************Second line**************************************************
        pl1 = pl2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[1][i] == 1) {
                pl1++;
            }
            if (board[1][i] == 2) {
                pl2++;
            }
        }
        
        
        //Computer plays
        
        if(pl1==0&&pl2==2)
        {
            for(int i=0;i<3;i++)
            {
                if(board[1][i]==0)
                {
                    board[1][i]=2;
                    System.out.println("1 "+i);
                    return;
                }
            }
        }
        //computer blocks opponents winning
        if(pl1==2&&pl2==0)
        {
            for(int i=0;i<3;i++)
            {
                if(board[1][i]==0)
                {
                    board[1][i]=2;
                    System.out.println("1 "+i);
                    return;
                }
            }
        }
        
        //**********************************third line*************************************************
        pl1 = pl2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[2][i] == 1) {
                pl1++;
            }
            if (board[2][i] == 2) {
                pl2++;
            }
        }
        
        
        //Computer plays
        
        if(pl1==0&&pl2==2)
        {
            for(int i=0;i<3;i++)
            {
                if(board[2][i]==0)
                {
                    board[2][i]=2;
                    System.out.println("2 "+i);
                    return;
                }
            }
        }
        //computer blocks opponents winning
        if(pl1==2&&pl2==0)
        {
            for(int i=0;i<3;i++)
            {
                if(board[2][i]==0)
                {
                    board[2][i]=2;
                    System.out.println("2 "+i);
                    return;
                }
            }
        }
        
        //*************************************first column**********************************************************
        pl1 = pl2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[i][0] == 1) {
                pl1++;
            }
            if (board[i][0] == 2) {
                pl2++;
            }
        }
        
        
        //Computer plays
        
        if(pl1==0&&pl2==2)
        {
            for(int i=0;i<3;i++)
            {
                if(board[i][0]==0)
                {
                    board[i][0]=2;
                    System.out.println(i+" 0");
                    return;
                }
            }
        }
        //computer blocks opponents winning
        if(pl1==2&&pl2==0)
        {
            for(int i=0;i<3;i++)
            {
                if(board[i][0]==0)
                {
                    board[i][0]=2;
                    System.out.println(i+" 0");
                    return;
                }
            }
        }
        
        //**************************************Second column*********************************************************************
        pl1 = pl2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[i][1] == 1) {
                pl1++;
            }
            if (board[i][1] == 2) {
                pl2++;
            }
        }
        
        
        //Computer plays
        
        if(pl1==0&&pl2==2)
        {
            for(int i=0;i<3;i++)
            {
                if(board[i][1]==0)
                {
                    board[i][1]=2;
                    System.out.println(i+" 1");
                    return;
                }
            }
        }
        //computer blocks opponents winning
        if(pl1==2&&pl2==0)
        {
            for(int i=0;i<3;i++)
            {
                if(board[i][1]==0)
                {
                    board[i][1]=2;
                    System.out.println(i+" 1");
                    return;
                }
            }
        }
        
        //**************************************Third column**********************************************************************************
        pl1 = pl2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[i][2] == 1) {
                pl1++;
            }
            if (board[i][2] == 2) {
                pl2++;
            }
        }
        
        
        //Computer plays
        
        if(pl1==0&&pl2==2)
        {
            for(int i=0;i<3;i++)
            {
                if(board[i][2]==0)
                {
                    board[i][2]=2;
                    System.out.println(i+" 2");
                    return;
                }
            }
        }
        //computer blocks opponents winning
        if(pl1==2&&pl2==0)
        {
            for(int i=0;i<3;i++)
            {
                if(board[i][2]==0)
                {
                    board[i][2]=2;
                    System.out.println(i+" 2");
                    return;
                }
            }
        }

        //**************************************left to right diagonal*******************************************************
        pl1 = pl2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[i][i] == 1) {
                pl1++;
            }
            if (board[i][i] == 2) {
                pl2++;
            }
        }
        
        
        //Computer plays
        
        if(pl1==0&&pl2==2)
        {
            for(int i=0;i<3;i++)
            {
                if(board[i][i]==0)
                {
                    board[i][i]=2;
                    System.out.println(i+" "+i);
                    return;
                }
            }
        }
        //computer blocks opponents winning
        if(pl1==2&&pl2==0)
        {
            for(int i=0;i<3;i++)
            {
                if(board[i][i]==0)
                {
                    board[i][i]=2;
                    System.out.println(i+" "+i);
                    return;
                }
            }
        }

        //***************************************Right to left diagonal****************************************************************************
        pl1 = pl2 = 0;
        for (int i = 0; i <= 2; i++) {
            if (board[i][2 - i] == 1) {
                pl1++;
            }
            if (board[i][2 - i] == 2) {
                pl2++;
            }
        }
        
        
        
        //Computer plays
        
        if(pl1==0&&pl2==2)
        {
            for(int i=0;i<3;i++)
            {
                if(board[i][2-i]==0)
                {
                    board[i][2-i]=2;
                    System.out.println(i+" "+(2-i));
                    return;
                }
            }
        }
        //computer blocks opponents winning
        if(pl1==2&&pl2==0)
        {
            for(int i=0;i<3;i++)
            {
                if(board[i][2-i]==0)
                {
                    board[i][2-i]=2;
                    System.out.println(i+" "+(2-i));
                    return;
                }
            }
        }
        for(int i=0;i<3;i++)
            for(int j=0;j<3;j++)
            {
                if (board[i][j]==0)
                {
                    board[i][j]=2;
                    System.out.println(i+" "+j);
                    return;
                }
            }
        //*******************************************************************************************************************
    }

    public static void main(String[] args) {
        TicTacToe t = new TicTacToe();
        t.play();
    }

}
