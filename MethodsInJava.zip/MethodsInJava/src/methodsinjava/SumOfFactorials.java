/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package methodsinjava;

/**
 *
 * @author PRADY
 */
public class SumOfFactorials {
    static int factorial(int n)
    {
        int f=1;
        for(int i=1;i<=n;i++)
            f=f*i;
        return f;
    }
    public static void main(String[] args)
    {
        int sum=0;
        for(int i=1;i<=5;i++)
        {
            int x=factorial(i);
            sum=sum+x;
            System.out.println(factorial(i));
        }
        System.out.println(sum);
    }
    
}
