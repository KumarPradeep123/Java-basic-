/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package methodsinjava;

/**
 *
 * @author PRADY
 */
public class MethodsWithReturnTypes {
    public static void main(String[] args)
    {
        int x=add(44,2);
        System.out.println(x);
        x=factorial(5);
        System.out.println(x);
    }
    
    static int add(int a,int b)
    {
        int sum=a+b;
        return sum;
    }
    static int factorial(int n)
    {
        int f=1;
        for(int i=1;i<=n;i++)
            f=f*i;
        return f;
    }
}
