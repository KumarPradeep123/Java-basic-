/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package methodsinjava;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class function4 {
    public static void main (String[] args)
    {
       pyramid(10);
        
       
    }
    static void pyramid(int n)
    {
           for (int i=1; i<=n; i++)
           {
            for(int j=1; j<=n-i; j++)
                System.out.print(" ");
            for(int k=1;k<=i;k++)
                   System.out.print("*");
            System.out.println();
            
                }
    }
    }


