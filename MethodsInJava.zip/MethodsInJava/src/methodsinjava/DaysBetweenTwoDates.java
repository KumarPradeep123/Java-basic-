/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package methodsinjava;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class DaysBetweenTwoDates {
    static String daysname(int n)
    {
        switch(n)
        {
            case -6: return "Sunday";
            case -5: return "Monday";
            case -4: return "Tuesday";
            case -3: return "Wednesday";
            case -2: return "Thursday";
            case -1: return "Friday";
            case 0: return "Saturday";
            case 1: return "Sunday";
            case 2: return "Monday";
            case 3: return "Tuesday";
            case 4: return "Wednesday";
            case 5: return "Thursday";
            case 6: return "Friday";
        }   
          return "Invalid";      
              
       
    }
    static int compare(int d1,int m1,int y1,int d2,int m2,int y2)
    {
        //-1 if D1>D2, 0 if D1==D2, 1 if D2>D1
        if(y1>y2)
            return -1;
        if(y1<y2)
            return 1;
        if(m1>m2)
            return -1;
        if(m1<m2)
            return 1;
        if(d1>d2)
            return -1;
        if(d1<d2)
            return 1;
        else
            return 0;
            
      }
    static int getDays(int d1,int m1,int y1,int d2,int m2,int y2)
    {
        //D2>=D1
        //10-9-2017  11-10-2019
        //11-10-2019  10-9-2017
       int x= compare(d1, m1, y1, d2, m2, y2);
       int sign=1;
       if(x==-1)
       {
           int t=d1;
           d1=d2;
           d2=t;
           sign=-1;
           
           t=m1;
           m1=m2;
           m2=t;
           
           
           t=y1;
           y1=y2;
           y2=t;
       }
       
        
        int p1=d1-1;
        int p2=d2-1;
        int p3=0;
        for(int month=1;month<=m1-1;month++)            
            p3=p3+daysInMonth(month,y1);
        
        int p4=0;
        for(int month=1;month<=m2-1;month++)
            p4=p4+daysInMonth(month,y2); 
            
        int p5=0;
        for(int year=y1;year<=y2-1;year++)
            if(isLeapYear(year))
                p5=p5+366;
        else
                p5=p5+365;
        
        return sign*(p2-p1+p4-p3+p5);
        
        
    }
    
    static boolean isLeapYear(int year)
    {
        if(year % 400==0)
       return true;
        
   if(year % 4==0 && year % 100!=0)
       return true;
        return false;
    }   
static int daysInMonth(int month,int year)
{
   if(month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12 )
       return 31;
   
   if(month==2)
   if(isLeapYear(year))
       return 29;
   else
       return 28;
   
   else 
       return 30;
   
}
public static void main(String[] args)
{
    
        
int diff=getDays(23, 9, 2017, 16, 7, 1998);

String a=daysname(diff % 7);

    System.out.println(a);
}
}
