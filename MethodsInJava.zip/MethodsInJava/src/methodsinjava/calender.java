/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package methodsinjava;

import static methodsinjava.DaysBetweenTwoDates.compare;
import static methodsinjava.DaysBetweenTwoDates.getDays;
import static methodsinjava.DaysBetweenTwoDates.isLeapYear;

/**
 *
 * @author PRADY
 */
public class calender {
    public static void main(String[] args)
{
    int diff=getDays(22,9, 2017, 20, 8, 2018);
    System.out.println(diff);
}
    static int daysInMonth(int month,int year)
{
   if(month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12 )
       return 31;
   
   if(month==2)
   if(isLeapYear(year))
       return 29;
   else
       return 28;
   
   else 
       return 30;
   
}
static boolean isLeapYear(int year)
    {
        if(year % 400==0)
       return true;
        
   if(year % 4==0 && year % 100!=0)
       return true;
        return false;
    }   

    static int getDays(int d1,int m1,int y1,int d2,int m2,int y2)
    {
       
       
        
        int p1=d1-1;
        int p2=d2-1;
        int p3=0;
        for(int month=1;month<=m1-1;month++)            
            p3=p3+daysInMonth(month,y1);
        
        int p4=0;
        for(int month=1;month<=m2-1;month++)
            p4=p4+daysInMonth(month,y2); 
            
        int p5=0;
        for(int year=y1;year<=y2-1;year++)
            if(isLeapYear(year))
                p5=p5+366;
        else
                p5=p5+365;
        
        return (p2-p1+p4-p3+p5);
        
        
    }
}