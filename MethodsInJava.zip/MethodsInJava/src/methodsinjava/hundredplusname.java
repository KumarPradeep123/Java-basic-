/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package methodsinjava;

/**
 *
 * @author PRADY
 */
public class hundredplusname {
    static String hundreds(int n)
    {
        if(n<=99)
            return "";
        if(n % 10==0)
            return getTens(n);
        if(n>=11 && n<=19)
            return eleventonineteen(n);
        if(n>=100 && n<=999)
        {
        int hundredpart=n/100;
        int tenpart=n%100;
        tenpart=tenpart /10;
        tenpart=tenpart*10;
        int digitpart =n %100;
        digitpart=digitpart%10;
        return units(hundredpart) + " " + "hundred" + " " + getTens(tenpart) + " " + units(digitpart);
        }
       return "Invalid"; 
 }
   
    static String getTens(int n)
    {
        switch(n)
        {
            case 10:return "Ten";
            case 20:return"Twenty";
                case 30:return "Thirty";
                    case 40:return "Forty";
                        case 50:return "Fifty";
                        case 60:return "Sixty";
                        case 70:return "Seventy";
                            case 80:return "Eighty";
                            case 90:return "Ninety";
                                
        }
        return "Invalid";
        }
   
    static String units(int n)
    {
        switch(n)
        {
            case 0: return "Zero";
            case 1: return "One";
            case 2: return "Two";
            case 3: return "Three";
                     case 4: return "Four";
                     case 5: return "Five";
                         case 6: return "Six";
                             case 7: return "Seven";
                                 case 8: return "Eight";
                                     case 9: return "Nine";
                                                         
        }
        return "Invalid";
        }
    static String eleventonineteen(int n)
    {
    switch(n)
      {
          case 11:return "Eleven";
              case 12:return "Twelve";
                  case 13:return "Thirteen";
                  case 14:return "Fourteen";
                  case 15:return "Fifteen";
                      case 16:return "Sixteen";
                          case 17:return "Seventeen";
                          case 18:return "Eighten";
                          case 19:return "Nineteen";
    }
    return "Invalid";
                              
                      
              }
    public static void main(String[] args)
    {
      for(int n=0;n<=999;n++)  
            System.out.println(hundreds(n) + ",");
    }
    

}



