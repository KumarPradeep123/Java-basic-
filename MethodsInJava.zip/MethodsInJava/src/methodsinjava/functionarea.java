/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package methodsinjava;

/**
 *
 * @author PRADY
 */
public class functionarea {
    public static void main (String[] args)
    {
       int y=area(9,7);
        System.out.println(y);
    double x=radious(200);
        System.out.println(x);
        double z=circumference(300);
        System.out.println(z);
        
    }
    static int area(int l, int b)
    {
        int area=l*b;
        return area;
    }
    static double radious(int n)
    {
        double r=Math.sqrt(n/Math.PI);
        return r;
        
    }
    static double circumference(int p)
    {
        double radious=Math.sqrt(p/Math.PI);
        double circumference=2*Math.PI*radious;
        return circumference;
        
    }
}