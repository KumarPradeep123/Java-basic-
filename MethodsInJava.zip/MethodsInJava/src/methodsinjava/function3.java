/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package methodsinjava;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class function3 {
    public static void main (String[] args)
    {
        Scanner s=new Scanner (System.in);
        System.out.println("put the value of p, r, t");
        int p=s.nextInt();
        int r=s.nextInt();
        int t=s.nextInt();
        int x=si(p, r, t);
        System.out.println(x);
        double y=ci(p, r, t);
        System.out.println(y);
        
    }
    static int si(int p, int r, int t)
    {
        int si=(p*r*t)/100;
        return si;
    }
    static double ci(int p, int r, int t)
    {
    double a=p*(Math.pow(1+(r/100.0),t));
        double ci=a-p;
        return ci;
    }
}
