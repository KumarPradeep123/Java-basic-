/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package methodsinjava;

import java.util.Scanner;

/**
 *
 * @author PRADY
 */
public class function2 {
    public static void main (String[] args)
    {
        Scanner s=new Scanner (System.in);
        System.out.println("put the length of triangle");
        int a=s.nextInt();
        int b=s.nextInt();
        int c=s.nextInt();

        double x=areaoftringle(a, b, c);
        System.out.println(x);
        
    }
    static double areaoftringle(int a, int b, int c)
    {
        int s=(a+b+c)/2;
        double areaoftringle=Math.sqrt(s*(s-a)*(s-b)*(s-c));
                return areaoftringle;
    }
}
