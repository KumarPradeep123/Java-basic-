/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package methodsinjava;

/**
 *
 * @author PRADY
 */
public class MethodsInJava {

    static void f(int n,String message)
    {
           for(int i=1;i<=n;i++)
            System.out.println(message);
    }
    static void f(int n)
    {
        for(int i=1;i<=n;i++)
            System.out.println("Hello");
    }
  static void f()
  {
      System.out.println("Hello");
      System.out.println("Hello");
      System.out.println("Hello");
      System.out.println("Hello");
      System.out.println("Hello");
      
      
  }
  
    public static void main(String[] args) {
        f();
        System.out.println("\n\n");
        f();
        System.out.println("\n\n");
        f(3);
        System.out.println("\n\n");
        f(4,"Bye");
    }
}
