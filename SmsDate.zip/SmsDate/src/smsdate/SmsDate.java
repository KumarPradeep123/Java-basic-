package smsdate;

import java.util.Calendar;

public class SmsDate {
    private int day,month,year,hour,minute;

    public SmsDate(int day, int month, int year, int hour, int minute) {
        this.day = day;
        this.month = month;
        this.year = year;
        this.hour = hour;
        this.minute = minute;
    }
    public SmsDate()
    {
       Calendar calendar= Calendar.getInstance();
       this.day=calendar.get(Calendar.DAY_OF_MONTH);
       this.month=calendar.get(Calendar.MONTH) + 1;
       this.year=calendar.get(Calendar.YEAR);
       this.hour=calendar.get(Calendar.HOUR);
       this.minute=calendar.get(Calendar.MINUTE);
        
    }
    public static int compareDates(SmsDate d1,SmsDate d2)
    {
        if(d1.year<d2.year)
            return -1;
         if(d1.year>d2.year)
            return 1;
         if(d1.month<d2.month)
            return -1;
         if(d1.month>d2.month)
            return 1;
         if(d1.day<d2.day)
            return -1;
         if(d1.day>d2.day)
            return 1;
         if(d1.hour<d2.hour)
            return -1;
         if(d1.hour>d2.hour)
            return 1;
         if(d1.minute<d2.minute)
            return -1;
         if(d1.minute>d2.minute)
            return 1;
         return 0;
    }
    public boolean isPast()
    {
        SmsDate date=new SmsDate();
        int n=compareDates(this, date);
        if(n<=0)
            return true;
        return false;
    }
     public boolean isFuture()
    {
        SmsDate date=new SmsDate();
        int n=compareDates(this, date);
        if(n>0)
            return true;
        return false;
    }
    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    @Override
    public String toString() {
        return "SmsDate{" + "day=" + day + ", month=" + month + ", year=" + year + ", hour=" + hour + ", minute=" + minute + '}';
    }
    
    public static void main(String[] args) {
     SmsDate date=new  SmsDate();
        System.out.println(date);
        SmsDate sd=new SmsDate(15, 12, 2017, 20, 10);
        System.out.println(sd);
        System.out.println(sd.isPast());
    }
    
}
