package pattern;
import java.util.Scanner;
public class entry {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.println("Enter number : ");
        int n=s.nextInt();
        int h=(2*n)-1;
        char ch;
        for(int i=n;i>=1;i--)
        {
            if(i!=n)
            {
            for(int l=1;l<=i;l++)
            {
                ch=(char)('A'+(l-1));
                System.out.print(ch+" ");
            }
            for(int m=1;m<=h-(2*i);m++)
            {
                System.out.print("  ");
            }    
            for(int r=1;r<=i;r++)
            {
                int y=1+(i-r);
                ch=(char)('A'+(y-1));
                System.out.print(ch+" ");
            }
            }
            else
            {
                for(int x=1;x<=n;x++)
                {
                    ch=(char)('A'+(x-1));
                    System.out.print(ch+" ");
                }
                for(int x=n-1;x>=1;x--)
                {
                    ch=(char)('A'+(x-1));
                    System.out.print(ch+" ");
                }
            }
            System.out.println();
        }
    }
}
