package pattern;

import java.util.Scanner;

public class while_pattern {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.println("Enter number : ");
        int i=1,n=s.nextInt();
        while (i <= n)
        {
            int j=1;
            while(j <= n - i)
            {
                System.out.print(" ");
                j++;
            }
            int k=1;
            while(k <= i)
            {
                System.out.print("* ");
                k++;
            }
            System.out.println();
            i++;
        }
    }
}
