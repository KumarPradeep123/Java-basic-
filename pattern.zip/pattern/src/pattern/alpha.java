package pattern;

import java.util.Scanner;

public class alpha {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.print("Enter Letter : ");
        String ch=s.next();
        System.err.print("Enter Size (above 10) : ");
        int n=s.nextInt();
        switch(ch)
        {
            case "a":{}
            case "A":
            {
                if(n%2==0)
                    n++;
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        int x=(int)Math.ceil(n/2);
                        if(i==1||i==x+1||j==1||j==n)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                }
                break;
            }                                   //Case for A ends here
            case "b":{}
            case"B":
            {
                if(n%2==0)
                    n=n+1;
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        int x=(int)Math.ceil(n/2);
                        if((i==1||i==x+1||i==n)&&(j<=n-2))
                            System.out.print("*");
                        else if(j==1)
                            System.out.print("*");
                        else if((i==2||i==x||i==x+2||i==n-1)&&(j==n-1))
                            System.out.print("*");
                        else if(((i>2&&i<=x-1)||(i>(x+2)&&i<=n-2))&&(j==n))
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                }
                break;
            }                                   //Case for B ends here
            case "c":{}
            case "C":
            {
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        if(i==1||i==n)
                            System.out.print("*");
                        else if(j==1)
                            System.out.print("*");
                    }
                    System.out.println();
                }
                break;
            }                                   //Case for C ends here
            case "d":{}
            case "D":
            {
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        if((i==1||i==n)&&(j<=n-2))
                            System.out.print("*");
                        else if(j==1)
                            System.out.print("*");
                        else if((i==2||i==n-1)&&(j==n-1))
                            System.out.print("*");
                        else if((i>2&&i<n-1)&&(j==n))
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                }
                break;
            }                                   //Case for D ends here
            case "e":{}
            case "E":
            {
                if(n%2==0)
                    n=n+1;
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        int x=(int)Math.ceil(n/2);
                        if((i==1||i==x+1||i==n)&&(j<=n-2))
                            System.out.print("*");
                        else if(j==1)
                            System.out.print("*");
                    }
                    System.out.println();
                }
                break;
            }                                   //Case for E ends here
            case "f":{}
            case "F":
            {
                if(n%2==0)
                    n=n+1;
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        int x=(int)Math.ceil(n/2);
                        if((i==1||i==x+1)&&(j<=n-2))
                            System.out.print("*");
                        else if(j==1)
                            System.out.print("*");
                    }
                    System.out.println();
                }
                break;
            }                                   //case for F ends here
            case "g":{}
            case "G":
            {
                
            }                                   //case for G ends here
            case "h":{}
            case "H":
            {
                if(n%2==0)
                    n++;
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        int x=(int)Math.ceil(n/2);
                        if(i==x+1||j==1||j==n)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                }
                break;
            }                                   //case for H ends here
            case "i":{}
            case "I":
            {
                if(n%2==0)
                    n++;
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        int x=(int)Math.ceil(n/2);
                        if(i==1||j==x+1||i==n)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                }
                break;
            }                                   //case for I ends here
            case "j":{}
            case "J":
            {
                if(n%2==0)
                    n++;
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        int x=(int)Math.ceil(n/2);
                        if((i==1||j==x+1)&&(i<=n-3))
                            System.out.print("*");
                        else if((j==1||j==x+1)&&(i==n-2||i==n-1))
                            System.out.print("*");
                        else if((i==n)&&(j>=2&&j<=x))
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                }
                break;
            }                                   //case for J ends here
        }                                       //switch ends here
    }
}
