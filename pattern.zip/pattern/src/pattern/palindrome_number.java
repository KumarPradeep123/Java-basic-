package pattern;
import java.util.Scanner;
public class palindrome_number {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.print("Enter the number : ");
        int num=s.nextInt(),n=num,d=0,a;
        while(n>0)          //Loop which reverses the digits
        {
            a=n%10;
            d=(d*10)+a;
            n=n/10;
        }
        System.out.println("Reverse of "+num+" is "+d);
        if(num==d)
            System.out.println("Since "+num+" and "+d+" is same so "+num+" is a palindrome number.");
        else
            System.out.println("Since "+num+" and "+d+" is not same so "+num+" is not a palindrome number.");
    }
}
