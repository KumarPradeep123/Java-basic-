package pattern;
import java.util.Scanner;
public class num_pattern {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n-i;j++)
            {
                System.out.print(" ");
            }
            for(int k1=1;k1<=i;k1++)
            {
                System.out.print(k1);
            }
            for(int k2=i-1;k2>=1;k2--)
            {
                System.out.print(k2);
            }
            System.out.println();
        }
    }
}
