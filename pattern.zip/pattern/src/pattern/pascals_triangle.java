package pattern;

import java.util.Scanner;

public class pascals_triangle {
    static int pascal(int y,int x)
    {
        if(x==1)
        {return 1;}
        else
        if(x==y)
        {return 1;}
        else
            return (pascal((y-1),(x-1))+pascal((y-1),x));
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter number of rows : ");
        int n = s.nextInt();
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            for (int k = 1; k <=i; k++) {
                int x=pascal(i,k);
                System.out.print(x+" ");
            }
            System.out.println();
        }
    }
}