/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package math;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author PRADEEP KUMAR
 */
public class TImeDate {
    public static void main(String[] args){
        Date date=new Date();
     
       Calendar cal = Calendar.getInstance(); 
    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    date=cal.getTime();
    String d=dateFormat.format(date);
    
System.out.println(d);

    }
    
}
