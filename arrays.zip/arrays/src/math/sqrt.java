/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package math;

import java.util.Scanner;

/**
 *
 * @author Virus
 */
public class sqrt {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int x1=0,y1=4,x2=9,y2=8;
        double distance=Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
        System.out.println(distance);
    }
    
}
