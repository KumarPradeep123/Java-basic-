package arrays;
import java.util.Scanner;
public class insertion {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int []a={5,8,9,2,7};
        for(int i=0;i<=a.length-1;i++)
        {
            System.out.print(a[i]+"  ");
        }
        System.out.println();
        System.out.print("Enter element to be inserted : ");
        int element=s.nextInt();
        System.out.print("Enter location of element : ");
        int location=s.nextInt();
        for(int i=a.length;i>=location;i--)
        {
            a[i]=a[i-1];
        }
        int num=a.length;
        a[location-1]=element;
        for(int i=0;i<=num;i++)
        {
            System.out.print(a[i]+" ");
        }
    }
}
