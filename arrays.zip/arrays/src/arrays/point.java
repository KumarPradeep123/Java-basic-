package arrays;
public class point {
    public static void main(String[] args) {
        int []a={10,15,19,52,27,52,63,15};
        for(int i=0;i<=a.length-2;i++)
        {
            if(a[i+1]<a[i])
                System.out.println("Values decreased at position : "+(i+1));
        }
    }
}
