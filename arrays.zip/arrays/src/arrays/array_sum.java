package arrays;
import java.util.Scanner;
public class array_sum {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int[] a={22,3,4,-55,6,-7};
        int sum=0,max=a[0],pos=0;
      
        
        max=a[0];
        for(int j=0;j<a.length;j++)
        {
            sum=sum+a[j];
            if(a[j]>max)
            {
                max=a[j];
                pos=j;
            }
        }
        System.out.printf("Sum=%s\nMax=%s\nPosition=%s\n",sum,max,pos);
    }
    
}
