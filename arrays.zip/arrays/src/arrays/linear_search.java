package arrays;
import java.util.Scanner;
public class linear_search {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.print("Enter size of array :");
        int n=s.nextInt();
        int[] a=new int [n];
        System.out.println("Enter values of array :");
        for(int i=0;i<n;i++)
        {
            a[i]=s.nextInt();
        }
        int item,pos=0;
        System.err.println("Enter item to be searched : ");
        item=s.nextInt();
        for(int j=0;j<a.length;j++)
        {
            if(a[j]==item)
            {
                pos=j;
                System.out.printf("Item found at position %s\n",pos);
                return;
            }
        }
        System.out.printf("Item not found !!!!!\n");
    }
}
