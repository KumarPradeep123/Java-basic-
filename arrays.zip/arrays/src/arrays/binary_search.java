package arrays;

import java.util.Scanner;

public class binary_search {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.print("Enter element to be searched : ");
        int n=s.nextInt();
        int []a={1,8,9,10,17,18,21,35};
        int l=0,r=a.length-1,mid=0;
        while(l<r)
        {
            mid=(l+r)/2;
            if(a[mid]==n)
            {
                System.out.println("Item found at "+mid);
                return;
            }
            else if(n>a[mid])
                l=mid+1;
            else if(n<a[mid])
                r=mid-1;
        }
        System.out.println("Not found");
    }
}
