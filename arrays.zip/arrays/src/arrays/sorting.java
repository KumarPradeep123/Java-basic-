package arrays;
import java.util.Scanner;
public class sorting {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.err.println("Enter size of array : ");
        int n=s.nextInt();
        int[] a = new int[n];
        System.err.println("Enter array elements : ");
        for(int i=0;i<n;i++)
            a[i]=s.nextInt();
        int max=a[0],min=a[0],countmax=0,countmin=0;
        System.out.println("\nUnsorted array is : ");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + "  ");
            if(max<a[i])
            {
                max=a[i];
            }
            if(min>a[i])
            {
                min=a[i];
            }
        }
        System.out.println("\n");
        System.out.print("Maximum : "+max+" found times at position(s) ");
        for(int i=0;i<a.length;i++)
        {
            if(max==a[i])
            {
                countmax++;
                System.out.print(i+"  ");
            }
        }
        System.out.print("\nMinimum : "+min+" found times at position(s) ");
        for(int i=0;i<a.length;i++)
        {
            if(min==a[i])
            {
                countmin++;
                System.out.print(i+"  ");
            }
        }
        System.out.println("\nTotal number of elements are : "+a.length+"\n");
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a.length; j++) {
                if (a[i] < a[j]) {
                    int temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }
        System.out.println("Sorted array in increasing order : ");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + "  ");
        }
        System.out.println("\n");
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a.length; j++) {
                if (a[i] > a[j]) {
                    int temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }
        System.out.println("Sorted array in decreasing order : ");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + "  ");
        }
        System.out.println("\n");
    }
}
