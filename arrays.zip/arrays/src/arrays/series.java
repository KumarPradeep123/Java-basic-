package arrays;
public class series
{
    public static void main(String[] args)
    {
        int []a={10,15,456,25,36,25,26,27,29,51,0};
        int p1=0,p2=0,length,max=0,count=0,pms=0,pme=0;
        for(int i=1;i<=a.length-1;i++)
        {
            if(a[i-1]>a[i])
            {
                count++;
                p2=i;
                length=p2-p1;
                if(length>max)
                {
                    pms=p1;
                    pme=p2-1;
                    max=length;
                }
                for(int j=p1;j<=p2-1;j++)
                    System.out.print(a[j]+" ");
                System.out.println("\t\tLength is "+length);
                p1=p2;
            }
        }
        System.out.println("\nMaximum length of continuous series is "+max);
        for(int i=pms;i<=pme;i++)
            System.out.print(a[i]+" ");
        System.out.println("\n\nTotal number of series is "+count);
    }
}
