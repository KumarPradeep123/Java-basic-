
import java.util.Scanner;
public class Customer_Details {
String Name,Address,Contact;
    public Customer_Details() {
        Scanner s=new Scanner(System.in);
        System.out.print("\tEnter Name : ");
        Name=s.nextLine();
        System.out.print("\tEnter Address : ");
        Address=s.nextLine();
        System.out.print("\tEnter Contact Number : ");
        Contact=s.nextLine();
    }
    public static void main(String[] args) {
        Customer_Details cd=new Customer_Details();
        System.out.println(cd);
    }

    @Override
    public String toString() {
        return "-------------------------------------------\nCustomer's Name : " + Name + "\nCustomer's Address : " + Address + "\nCustomer's Contact : " + Contact+"\n-------------------------------------------";
    }
}
