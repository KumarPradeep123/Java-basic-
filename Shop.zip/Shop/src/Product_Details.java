
import java.util.Scanner;
public class Product_Details {
String P_Name;
final int price;
int Quantity,total;
    public Product_Details() {
        Scanner s=new Scanner(System.in);
        System.out.print("\tEnter Product Name : ");
        P_Name=s.nextLine();
        System.out.print("\tEnter Price : ");
        price=s.nextInt();
        System.out.print("\tEnter Quantity : ");
        Quantity=s.nextInt();
        total=price*Quantity;
    }
    public static void main(String[] args) {
        Product_Details pd=new Product_Details();
        System.out.println(pd);
    }

    @Override
    public String toString() {
        return "\n" + P_Name +"\t\t"+ price+"\t"+Quantity+"\t"+total;
    }
}
