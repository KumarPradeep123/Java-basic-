
import java.util.Scanner;

public class Bill {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter Customer Details");
        Customer_Details customer=new Customer_Details();
        System.out.println("Enter number of products : ");
        int x=s.nextInt();
        Product_Details product[]=new Product_Details[x];
        for(int a=0;a<x;a++)
        {
            System.out.println("Enter "+(a+1)+" Product Details ");
            product[a]=new Product_Details();
            System.out.println();
        }
        int total=0;
        for(int i=0;i<x;i++)
        {
            total=total+product[i].total;
        }
        System.out.println("-------------------------------------------\n\tCustomer Details\n"+customer);
        System.out.println("\tProduct's Details\n-------------------------------------------");
        for(int i=0;i<x;i++)
        System.out.println(product[i]);
        System.out.println("-------------------------------------------\nTotal Amount \t\t\t"+total);
    }
}
