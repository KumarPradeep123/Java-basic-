import java.util.Scanner;

public class exception {
    public static void main(String[] args) {
   try
   {
       Scanner s=new Scanner(System.in);
       int n=0;
       System.out.print("Enter value of X : ");
       int x=s.nextInt();
       int z=x/n;
   }
   catch(Exception ex)
   {
       System.out.println("Paglu ho ka be");
   }
}
}
