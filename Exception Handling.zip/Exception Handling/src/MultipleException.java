import java.util.Scanner;
public class MultipleException {
    public void main(String[] args) {
        outer : try
        {
            Scanner s=new Scanner(System.in);
            System.out.print("Enter a positive number : ");
            int x=s.nextInt();
            int n=0;
            if(x<0)
                throw new NegativeNumberException();
            if(x==0)
                throw new RuntimeException();
            int z=x/n;
            throw new ArithmeticException();
        }
        catch(NegativeNumberException ex)
        {
            System.out.println("Negative Number Exception !!!!!!");
        }
        catch(ArithmeticException ex)
        {
            System.out.println("Arithmetic Exception !!!!!!");
        }
        catch(RuntimeException ex)
        {
            System.out.println("Runtime Exception !!!!!!");
        }
        catch(Exception ex)
        {
            System.out.println("Unknown Exception !!!!!!");
        }
        finally
        {
            System.out.println("Bye Bye !!!!!!");
        }
    }
}
