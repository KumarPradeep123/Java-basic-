
import java.util.Scanner;

public class Product {
    int name;
    int price;
    public Product() throws Exception
    {
        Scanner s=new Scanner(System.in);
        System.out.print("Enter Product Price : ");
        price=s.nextInt();
        if(price <0)
        {
            Exception ex=new Exception("Bhaang Khaye ho ka bachha !!!!!");
            throw ex;
        }
        System.out.print("Enter Product Name : ");
        name=Integer.parseInt(s.nextLine());
    }

    @Override
    public String toString() {
        return "Product Name : " + name + "\nProduct Price : " + price;
    }
    
    public static void main(String[] args) {
        try
        {
   Product p1=new Product();
            System.out.println(p1);
        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
}
}
