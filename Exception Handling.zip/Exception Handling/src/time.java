
import java.util.Scanner;

public class time {

    int hr, min;

    public time(int h, int m) {
        hr = h;
        min = m;
    }

    public void check() {
        if (hr < 12) {
            System.out.println(hr + ":" + min + " AM");
        } else if (hr == 12) {
            System.out.println(hr + ":" + min + " PM");
        } else {
            System.out.println((hr - 12) + ":" + min + " PM");
        }
    }

    public static void main(String[] args)throws Exception {
        Scanner s = new Scanner(System.in);
        int hour, minute;
        while(true)
        try {
            System.out.print("Enter hour : ");
            hour = s.nextInt();
            if (hour < 0 || hour > 23) 
                throw new Exception("Ghanta sahi daal be !!!!!");
            System.out.print("Enter hour : ");
            minute = s.nextInt();
            if (minute < 0 || minute > 59) 
                throw new Exception("Minute sahi daal be !!!!!");
        time t = new time(hour, minute);
        t.check();
        }
    catch (Exception ex) {
            System.out.println(ex);
    }
}
}
