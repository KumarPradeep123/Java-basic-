
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class math_Class {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int a,b,c,max,min,mid;
        a=s.nextInt();
        b=s.nextInt();
        c=s.nextInt();
        max=Math.max(a,b);
        max=Math.max(max, c);
        min=Math.min(a,b);
        min=Math.min(min, c);
        mid=(a+b+c)-(max+min);
        System.out.print("Maximum is : "+max+"\n Minimum is : "+min+"\n Middle is : "+mid+"\n");
    }
    
}
