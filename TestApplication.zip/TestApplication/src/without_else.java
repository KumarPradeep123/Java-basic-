
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class without_else {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int a,b,c,d,e,max;
        System.err.println("Input 5 numbers : ");
        a=s.nextInt();
        b=s.nextInt();
        c=s.nextInt();
        d=s.nextInt();
        e=s.nextInt();
        max=a;
        if(b>max)
            max=b;
        if(c>max)
            max=c;
        if(d>max)
            max=d;
        if(e>max)
            max=e;
        System.out.println("Maximum is :"+max);
    }
}
