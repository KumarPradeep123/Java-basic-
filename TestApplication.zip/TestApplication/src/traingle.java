
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class traingle {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int a,b,c,temp;
        System.err.print("Enter sides :");
        a=s.nextInt();
        b=s.nextInt();
        c=s.nextInt();
        if(b>a)
        {
            temp=a;
            a=b;
            b=temp;
        }
      
            if(c>a)
            {
                temp=a;
                a=c;
                c=temp;
            }
        
        if ((b+c)<a)
        {
            System.out.println("Sorry ! Triangle is not possible.");
        }
        else
        {
            temp=0;
            if(a==b)
                temp++;
            if(b==c)
                temp++;
            if(c==a)
                temp++;
            if (temp==1)
                System.out.print("Triangle is Isoceles ");
            else
            if (temp==3)
                System.out.print("Triangle is Equilateral ");
            else
            if (temp==0)
                System.out.print("Triangle is Scalen ");
            if(a*a==b*b+c*c)
                System.out.println("and right angled triangle.");
            else
                System.out.println("but not a right angeled triangle.");
        }
    }
}
