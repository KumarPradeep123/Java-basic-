
import java.util.Scanner;

public class prime_while_optimized {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int a=s.nextInt(),limit,count=2,loop_counter=0,t1=4,t2;
        System.out.print("2, 3");
        int i=5;
        outer:while(i<=a)
        {
            t1=6-t1;
            t2=4;
            limit=(int)Math.sqrt(i);
            int j=5;
            while(j<=limit)
            {
                t2=6-t2;
                loop_counter++;
                if(i%j==0)
                {i=i+t1;continue outer;}
                j=j+t2;
            }
            i=i+t1;
            System.out.print(", "+i);
            count++;
        }
        System.out.println("\nTotal number of prime numbers till "+a+" is "+count);
        System.out.println("Total number of inner loop runned is "+loop_counter);
}
}
