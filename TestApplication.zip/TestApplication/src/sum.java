
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class sum
{
    public static void main(String[] args)
    {
        Scanner s = new Scanner(System.in);
        int a,b,sum;
        System.err.print("Enter the two numbers=");
        a=s.nextInt();
        b=s.nextInt();
        sum=a+b;
        System.out.println("sum="+sum);
    }  
}