
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class fail_pass {
    public static void main(String[] args) {
        Scanner s=new Scanner (System.in);
        int m1,m2,m3;
        System.err.println("Input marks of three subjects :");
        System.err.print("Marks1 : ");
        m1=s.nextInt();
        System.err.print("Marks2 : ");
        m2=s.nextInt();
        System.err.print("Marks3 : ");
        m3=s.nextInt();
        if(m1<40||m2<40||m3<40)
        {
            System.out.println("Fail");
        }
        else
        {
            double per;
            int div=0;
            per=(m1+m2+m3)/3.0;
            per=per*100;
            per=Math.round(per);
            per=per/100.0;
            if ( per<50)
                div=3;
            else
            if (per<70)
                div=2;
            else
            
                div=1;
            System.out.println("Passed with "+per+"%");
            System.out.println("Division : "+div);
        }
    }
}
