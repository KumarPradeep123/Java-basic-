
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class abt_triangle {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int s1,s2,s3,d1,d2,d3;
        System.err.println("Enter three values for sides : ");
        s1=s.nextInt();
        s2=s.nextInt();
        s3=s.nextInt();
        System.err.println("Enter the degree of each angles :");
        d1=s.nextInt();
        d2=s.nextInt();
        d3=s.nextInt();
        if ((d1+d2+d3)==180)
        {
            System.out.println("Triangle is possible");
            if ((s1==s2)&&(s2==s3))
            {
                System.out.println("Given triangle is Equilateral triangle.");
            }
            if((s1==s2)||(s2==s3)||(s3==s1))
            {
                System.out.println("Given triangle is Isoceles triangle.");
            }
            else
            {
                System.out.println("Given triangle is Scalen triangle.");
            }
            if((d1==90)||(d2==90)||(d3==90))
            {
            if ((s1>s2)&&(s1>s3))
            {
                if((s1*s1)==((s2*s2)+(s3*s3)))
                {
                    System.out.println((s1*s1)+" = "+(s2*s2)+" + "+(s3*s3));
                    System.out.println("It is a Right angeled triangle.");
                }
                else
                {
                    System.out.println("It is not a Right angeled triangle.");
                }
            }
            else
            {
                if((s2>s1)&&(s2>s3))
                {
                    if((s2*s2)==((s1*s1)+(s3*s3)))
                    {
                        System.out.println((s2*s2)+" = "+(s1*s1)+" + "+(s3*s3));
                        System.out.println("It is a Right angeled triangle.");
                    }
                    else
                    {
                        System.out.println("It is not Right angeled triangle.");
                    }
                }
                else
                {
                    if((s3*s3)==((s1*s1)+(s2*s2)))
                    {
                        System.out.println((s3*s3)+" = "+(s1*s1)+" + "+(s2*s2));
                        System.out.println("It is a Right angeled triangle.");
                    }
                    else
                    {
                        System.out.println("It is not Right angeled triangle.");
                    }
                }
            }
            }
            else
            {
                    System.out.println("It is not a right angeled triangle");
            }
        }
        else
        {
            System.out.println("Sorry triangle is not possible !!!!");
        }
    }
}
