/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class functions {
    public int add(int a,int b)
    {
        int c=a+b;
        return c;
    }
    public int sub(int a,int b)
    {
        int c;
        if (a>b)
            c=a-b;
        else
            c=b-a;
        return c;
    }
    public int mul(int a,int b)
    {
        int c=a*b;
        return c;
    }
    public int div(int a,int b)
    {
        int c;
        if(b>0)
            c=a/b;
        else
            return 0;
        return c;
    }
}
