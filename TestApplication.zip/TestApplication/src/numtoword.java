import java.util.Scanner;
public class numtoword
{
    public static void main(String[] args)
    {
        Scanner s=new Scanner(System.in);
        System.err.print("Input Number to be converted into into word till 99 :");
        String a[]={"Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten"};
        String b[]={"Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"};
        String c[]={" ","Ten","Twenty","Thirty","Fourty","Fifty","Sixty","Seventy","Eighty","Ninety"};
        //String d[]={"Hundred","Thousand","Lakh","Crore"};
        String word="";
        int num=s.nextInt(),n;//count=0;
        /*while(n>0)
        {
            n=n/10;
            count++;
        }
        for(int i=1;i<=count;i++)
        {
           int x=num/(int)(Math.pow(10,count));
           word=word+d[x];
        }
        System.out.println(word);*/       
        if (num>10&&num<20)
        {
            System.out.println(num+" = "+b[(num%10)-1]);
        }
        else
        if(num<=10)
        {
            System.out.println(num+" = "+a[num]);
        }
        else
        if (num>=20&&num<=99)
        {
            n=num/10;
            int x=num%10;
            System.out.print(num+" = "+c[n]);
            if(x!=0)
                System.out.println(" "+a[x]);
            else
                System.out.println();
        }
        else
            System.out.println("Out of Range !!!!!!!");
    }
}