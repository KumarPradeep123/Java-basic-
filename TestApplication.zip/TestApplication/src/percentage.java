import java.util.Scanner;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class percentage {
    public static void main(String[] args) {
        Scanner z=new Scanner(System.in);
        int m1,m2,m3;
        double per;
        System.err.print("Input marks 1 :");
        m1=z.nextInt();
        System.err.print("Input marks 2 :");
        m2=z.nextInt();
        System.err.print("Input marks 3 :");
        m3=z.nextInt();
        per=(m1+m2+m3)/3.0;
        System.out.println("Percentage is : "+per);
    }
}
