
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class phone_bill_ifelse {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.println("Enter number of calls : ");
        int calls=s.nextInt();
        final int rent=50;
        double total;
        
        if (calls<100)
            total=rent;
        else
            if(calls<200)
                total=rent+((calls-99)*0.50);
            else
                if(calls<300)
                    total=rent+50+((calls-199)*0.75);
                else
                    total=rent+50+75+(calls-299);
        System.out.println("Rent for "+calls+" calls is "+total);
        
    }
}
