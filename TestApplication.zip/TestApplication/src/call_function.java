
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class call_function {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.println("\tMenu");
        System.err.println("1.Add");
        System.err.println("2.Subtract");
        System.err.println("3.Multiply");
        System.err.println("4.Divide");
        System.err.print("Enter your choice ==>");
        int choice=s.nextInt();
        functions f=new functions();
        System.err.println("Enter two numbers :");
        int num1=s.nextInt(),num2=s.nextInt();
        double output;
        switch (choice)
        {
            case 1:
            {
                output=f.add(num1, num2);
                System.out.println("Output is : "+output);
                break;
            }
            case 2:
            {
                output=f.sub(num1, num2);
                System.out.println("Output is : "+output);
                break;
            }
            case 3:
            {
                output=f.mul(num1, num2);
                System.out.println("Output is : "+output);
                break;
            }
            case 4:
            {
                output=f.div(num1, num2);
                System.out.println("Output is : "+output);
                break;
            }
            default :System.out.println("Wrong choice !!!!!!!");
        }
    }
}