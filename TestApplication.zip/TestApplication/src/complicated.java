import java.util.Scanner;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class complicated {
    public static void main(String[] args) {
        int y;
        System.out.println((y=(new Scanner(System.in)).nextInt())+" is "+((y%400==0)||((y%4==0)&&(y%100!=0))?"Leap Year":"Not a leap year"));
        
    }
}
