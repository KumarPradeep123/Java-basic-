import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class phone_bill_switch
{
    public static void main(String[] args)
    {
        Scanner s=new Scanner(System.in);
        System.err.print("Enter number of calls : ");
        final int rent=50;
        int calls=s.nextInt();
        double total;
        switch(calls/100)
        {
            case 0:total=rent;break;
            case 1:total=rent+((calls-99)*0.5);break;
            case 2:total=rent+50+((calls-199)*.75);break;
            default:total=rent+50+75+((calls-299)*1.0);break;
        }
        System.out.println("Bill for "+calls+" is Rs."+total);
    }
}
