
import java.util.Scanner;

public class fibonicci_series {                                     //class khul gawa
    public static void main(String[] args) {                        //main function open huwa
        Scanner s=new Scanner(System.in);
        System.err.print("Enter till which fibonacci series is to printed :");
        int n=s.nextInt();
        int a=0,b=1;
        System.out.println(n+" numbers in Fibonacci series are :");
        System.out.print(a+", "+b);
        for(int i=3;i<=n;i++)
        {                                                           //for ka openning hai
            int c=a+b;
            System.out.print(", "+c);
            a=b;
            b=c;
        }                                                           //for ka closing hai
        System.out.println("\n");
}                                                                   //main function ka closing hai
}                                                                   //class close ho gaya
