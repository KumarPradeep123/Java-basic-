
import java.util.Scanner;

public class prime_number {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.print("Input the number to be checked : ");
        int a=s.nextInt();
        int limit=(int)Math.sqrt(a);
        if(a==0||a==1)
        {System.out.println(a+" cannot be checked.");return;}
        for(int i=2;i<=limit;i++)
        {
            if(a%i==0)
            {System.out.println(a+" is not a prime number.");return;}
        }
        System.out.println(a+" is a prime number.");
}
}
