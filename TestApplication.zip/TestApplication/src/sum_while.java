
import java.util.Scanner;

public class sum_while {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.println("Enter Values, press 0 when you are done");
        int n=s.nextInt(),sum=0,max=n,min=n,count=0;
        double avg;
        while(n>0)
        {
            sum=sum+n;
            max=Math.max(max, n);
            min=Math.min(min, n);
            n=s.nextInt();
            count++;
        }
        avg=(double)sum/count;
        System.out.println("Sum = "+sum+"\nMaximum = "+max+"\nMinimum = "+min+"\nAverage = "+avg+"\nTotal elements = "+count);
}
}
