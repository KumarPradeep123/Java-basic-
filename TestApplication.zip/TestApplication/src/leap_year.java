
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class leap_year {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int year;
        System.err.print("Input Year : ");
        year=s.nextInt();
        if(((year%4==0)&&(year%100!=0))||(year%400==0))
            System.out.println(year+" is a leap year.");
        else
            System.err.println(year+" is not a leap year.");
    }
    //2000 leap year
    //2016 leap year
    //2017 not leap year
    //1900 not leap year
}
