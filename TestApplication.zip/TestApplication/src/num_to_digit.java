
import java.util.Scanner;

public class num_to_digit {
    public static void main(String[] args) {
        Scanner s=new Scanner (System.in);
        System.err.println("Input number : ");
        int num=s.nextInt(),count=0;
        String a[]={"Hundred","Thousand","Lakh"};
        String b[]={"Ten","Twenty","Thirty","Fourty","Fifty","Sixty","Seventy","Eighty","Ninety"};
        String c[]={"Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"};
        String d[]={"One","Two","Three","Four","Five","Six","Seven","Eight","Nine"};
        String word="";
        if (num<0)
        {
            System.out.println("Wrong input !!!!!");
        }
        else
        {
            for(int i=num;i>=0;i=i/10)
            {
                count++;
            }
            System.out.println(count);
            if (count==1)
            {
                word=d[num];
            }
            System.out.println(word);
        }
}
}
