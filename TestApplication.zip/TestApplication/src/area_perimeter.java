
import java.util.Scanner;
import static java.lang.Math.*;
public class area_perimeter {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int choice1,choice2;
        double area,perimeter;
        System.out.println("\tMenu");
        System.out.println("1.Area");
        System.out.println("2.Perimeter");
        System.err.print("Enter your choice ==>");
        choice1=s.nextInt();
        System.out.println("\n\n\tSub Menu");
        System.out.println("1.Circle");
        System.out.println("2.Triangle");
        System.out.println("3.Square");
        System.out.println("4.Rectangle");
        System.err.print("Enter your choice ==>");
        choice2=s.nextInt();
        switch(choice1)
        {
            case 1: //Finds area
            {
                switch(choice2)
                {
                    case 1: //finds area of Circle
                    {
                        System.err.print("Input Radius of circle : ");
                        int r=s.nextInt();
                        area=PI*(r*r);
                        System.out.println("Area of circle with radius "+r+" is "+area);
                        break;
                    }
                    case 2: //finds area of Triangle
                    {
                        System.err.print("Input Sides of a triangle : ");
                        int a=s.nextInt(),b=s.nextInt(),c=s.nextInt();
                        double d=(a+b+c)/2;
                        area=sqrt((d*(d-a)*(d-b)*(d-c)));
                        System.out.println("Area of triangle with sides "+a+", "+b+" and "+c+" is "+area);
                        break;
                    }
                    case 3: //finds area of Square
                    {
                        System.err.print("Input one side of the square : ");
                        int a=s.nextInt();
                        area=a*a;
                        System.out.println("Area of square with sides "+a+" is "+area);
                        break;
                    }
                    case 4: //finds area of Rectanngle
                    {
                        System.err.println("Input length and breadth of the rectangle : ");
                        int l=s.nextInt(),b=s.nextInt();
                        area=l*b;
                        System.out.println("Area of rectangle with length "+l+" breadth "+b+" is "+area);
                        break;
                    }
                    default:System.out.println("Sorry! You entered Wrong Choice !!!!!");break;
                }
                break;
            }
            case 2: //finds perimeter
            {
                switch(choice2)
                {
                    case 1: //finds perimeter of Circle
                    {
                        System.err.print("Input Radius of circle : ");
                        int r=s.nextInt();
                        perimeter=2*(PI*r);
                        System.out.println("Perimeter of circle with radius "+r+" is "+perimeter);
                        break;
                    }
                    case 2: //finds perimeter of Triangle
                    {
                        System.err.print("Input Sides of a triangle : ");
                        int a=s.nextInt(),b=s.nextInt(),c=s.nextInt();
                        perimeter=a+b+c;
                        System.out.println("Perimeter of triangle with sides "+a+", "+b+" and "+c+" is "+perimeter);
                        break;
                    }
                    case 3: //finds perimeter of Square
                    {
                        System.err.print("Input one side of the square : ");
                        int a=s.nextInt();
                        perimeter=4*a;
                        System.out.println("Perimeter of square with sides "+a+" is "+perimeter);
                        break;
                    }
                    case 4: //finds perimeter of Rectangle
                    {
                        System.err.println("Input length and breadth of the rectangle : ");
                        int l=s.nextInt(),b=s.nextInt();
                        perimeter=2*(l+b);
                        System.out.println("Perimeter of rectangle with length "+l+" breadth "+b+" is "+perimeter);
                        break;
                    }
                    default:System.out.println("Sorry! You entered Wrong Choice !!!!!");break;
                }
                break;
            }
            default:System.out.println("Sorry! You entered Wrong Choice !!!!!");break;
        }
    }
}
