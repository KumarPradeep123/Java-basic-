
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class tri_area {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        double a,b,c,d,area;
        a=s.nextDouble();
        b=s.nextDouble();
        c=s.nextDouble();
        d=(a+b+c)/2.0;
        area=Math.sqrt((d*(d-a)*(d-b)*(d-c)));
        System.out.println(area);
    }
}
