
import java.util.Scanner;
public class SI
{
    public static void main(String[] args)
    {
        Scanner s=new Scanner(System.in);
        int p,r,t;
        double interest;
        System.out.print("Enter principle amount :");
        p=s.nextInt();
        System.out.print("Enter rate of interest :");
        r=s.nextInt();
        System.out.print("Enter time period :");
        t=s.nextInt();
        interest=(p*r*t)/100.0;
        System.out.println("Interest = "+interest);
    }
}
