
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class month {
    public static void main(String[] args) {
        Scanner s=new Scanner (System.in);
        System.err.print("Input month number :");
        int month=s.nextInt(),year;
        switch(month)
        {
            case 1:System.out.print("January has");break;
            case 2:break;
            case 3:System.out.print("March has");break;
            case 4:System.out.print("April has");break;
            case 5:System.out.print("May has");break;
            case 6:System.out.print("June has");break;
            case 7:System.out.print("July has");break;
            case 8:System.out.print("August has");break;
            case 9:System.out.print("September has");break;
            case 10:System.out.print("October has");break;
            case 11:System.out.print("November has");break;
            case 12:System.out.print("December has");break;
            default:System.out.print("Invalid month !!!!!!");
        }
        switch(month)
        {
            case 2:
            {
                System.out.println("Input year : ");
                year=s.nextInt();
                switch(year%400)
                {
                    case 0:System.out.println("Febraury has 29 days"); break;
                    default:
                    {
                        switch(year%4)
                        {
                            default:System.out.println("Febraury has 28 days");break;
                            case 0:
                            {
                                switch(year%100)
                                {
                                    case 0:System.out.println("Febraury has 28 days");break;
                                    default:System.out.println("Febraury has 29 days");
                                }
                            }
                        }
                    }
                }
            break;
            }
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:System.out.println(" 31 Days");break;
            case 4:
            case 6:
            case 9:
            case 11:System.out.println(" 30 Days");break;
            default:System.out.println("Invalid month !!!!!!");
        }
    }
}
