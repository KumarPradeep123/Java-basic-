
import java.util.Scanner;

public class optimized_prime_numbers {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.print("Enter the number till which you want prime numbers : ");
        int a=s.nextInt(),limit,count=2,loop_counter=0,t1=4,t2=4;
        System.out.print("2, 3");
        outer:for(int i=5;i<=a;i=i+t1)
        {
            t1=6-t1;
            t2=4;
            limit=(int)Math.sqrt(i);
            for(int j=5;j<=limit;j=j+t2)
     
            {
                t2=6-t2;
                loop_counter++;
                if(i%j==0)
                    continue outer;
            }
            System.out.print(", "+i);
            count++;
        }
        System.out.println("\nTotal number of prime numbers till "+a+" is "+count);
        System.out.println("Total number of inner loop runned is "+loop_counter);
}
}
