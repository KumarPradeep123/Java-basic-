
import java.util.Scanner;
public class reverse_fibonicci {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.println("Enter last desired two numbers in fabonacci series : ");
        int a=s.nextInt(),b=s.nextInt();
        if (a<b)
        {
            a=a+b;
            b=a-b;
            a=a-b;
        }
        System.out.print("Reverse fibonacci series starting from "+a+" is \n"+a+", "+b);
        for (int i=(a-b);i>=0;i--)
        {
            int c=a-b;
            if(c<0)
                break;
            System.out.print(", "+c);
            a=b;
            b=c;
        }
        System.out.println("");
}
}
