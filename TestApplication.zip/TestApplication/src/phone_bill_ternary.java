
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class phone_bill_ternary {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.print("Enter number of calls : ");
        final int rent=50;
        int calls=s.nextInt();
        double total=(calls<100)?rent:(calls>=100&&calls<200)?rent+((calls-99)*0.50):(calls>=200&&calls<300)?rent+50+((calls-199)*0.75):rent+50+75+(calls-299);
        System.out.println("Rent for "+calls+" calls is "+total);
    }
}
