
import java.util.Scanner;

public class prime_while {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int a=s.nextInt();
        int limit=(int)Math.sqrt(a);
        if(a==0||a==1)
        {System.out.println(a+" cannot be checked.");return;}
        int i=2;
        while(i<=limit)
        {
            if(a%i==0)
            {System.out.println(a+" is not a prime number.");return;}
            i++;
        }
        System.out.println(a+" is a prime number.");
}
}
