import java.util.Scanner;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class marked_price {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        double SP,MP,dis;
        SP=s.nextDouble();
        dis=s.nextDouble();
        MP=(SP*100.0)/(100.0-dis);
        System.out.println("Marked Price = "+MP);
    }
}
