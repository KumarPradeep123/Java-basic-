
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class leap {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.err.println("Enter Year :");
        int year=s.nextInt();
        switch(year%400)
        {
            case 0:System.out.println("Leap year"); break;
            default:
            {
                switch(year%4)
                {
                    default:System.out.println("Not a leap year");break;
                    case 0:
                    {
                        switch(year%100)
                        {
                            case 0:System.out.println("Not a leap year");break;
                            default:System.out.println("Leap Year");
                        }
                    }
                }
            }
        }
    }
}
