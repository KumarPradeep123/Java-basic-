
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class if_else {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int a,b,c,max;
        System.out.println("Input three numbers");
        a=s.nextInt();
        b=s.nextInt();
        c=s.nextInt();
        if (a>b)
        {
            if (a>c)
            {
                max=a;
            }
            else
            {
                max=c;
            }
        }
        else
        {
            if (b>c)
            {
                max=b;
            }
            else
            {
                max=c;
            }
        }
        System.out.println("Maximum number is : "+max);
    }
}
