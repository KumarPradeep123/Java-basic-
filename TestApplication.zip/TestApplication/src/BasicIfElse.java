/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Virus
 */
public class BasicIfElse {
    public static void main(String[] args) {
        int a=7,b=7,c=7;
        if(a==b)
            System.out.println("Print a=b");  
     
        if(a==c)
            System.out.println("Print a=c");
       
        
       
    }
}
