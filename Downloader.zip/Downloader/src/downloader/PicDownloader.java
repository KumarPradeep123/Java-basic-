/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package downloader;

import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.net.URI;
import java.net.URLConnection;
import java.util.Scanner;

/**
 *
 * @author PRADEEP KUMAR
 */
public class PicDownloader {
    //http://pradeep.softwareforyou.in/04.jpg
    public static void main(String[] args) {
        try
        {
           //URI uri=new URI("http://pradeep.softwareforyou.in/test.aspx");
           //URI uri=new URI("http://hypatiasoftwaresolutions.in");
           //URI uri=new URI("https://www.facebook.com/");
            URI uri = new URI("http://localhost:63379/website/page.aspx");
            URLConnection connection = uri.toURL().openConnection();
            java.io.DataInputStream din=new DataInputStream(connection.getInputStream());
            FileOutputStream fout=new FileOutputStream("g:\\out.jpg");
           int n=din.read();
            while(n!=-1)
            {
                fout.write(n);
                System.out.println(n);
                n=din.read();
            }
            fout.flush();
            fout.close();
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        
    }
}
