/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package downloader;

import com.sun.javafx.css.converters.URLConverter;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLConnection;
import java.sql.Connection;
import java.util.Scanner;

/**
 *
 * @author PRADEEP KUMAR
 */
public class NewClass {
    public static void main(String[] args) {
        try
        {
        URI uri=new URI("http://pradeep.softwareforyou.in/a.txt");
        URLConnection conn = uri.toURL().openConnection();
        Scanner s=new Scanner(conn.getInputStream());
        System.out.println(s.nextLine());
        }
        catch(Exception ex)
                {
                    
                }
                
    }
    
}
