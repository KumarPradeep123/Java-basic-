 
package downloader;

import java.net.URI;
import java.net.URLConnection;
import java.util.Scanner;
public class Downloader {

    public static void main(String[] args) {
        try
        {
           //URI uri=new URI("http://pradeep.softwareforyou.in/test.aspx");
           //URI uri=new URI("http://hypatiasoftwaresolutions.in");
           //URI uri=new URI("https://www.facebook.com/");
            URI uri = new URI("http://localhost:63379/website/page.aspx");
            URLConnection connection = uri.toURL().openConnection();
            Scanner scanner=new Scanner(connection.getInputStream());
            while(scanner.hasNextLine())
            {
                String line=scanner.nextLine();
                System.out.println(line);
            }
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        
    }
    
}
